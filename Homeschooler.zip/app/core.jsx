/* ===================================================================== *
 *  core.jsx — HomeschoolKit · Focus theme, icons, UI primitives, helpers
 *  Exports to window so other babel scripts can use them.
 * ===================================================================== */
const { useState, useEffect, useRef, useContext, createContext, useCallback, useMemo } = React;

/* ----------------------------- Theme ---------------------------------- */
const BASE_THEME = {
  bg: '#f6f8fa', surface: '#ffffff', surfaceAlt: '#eef2f6', surfaceSunken: '#f1f4f8',
  text: '#1b2430', textMuted: '#6a7585', textFaint: '#9aa4b2',
  border: '#e4e9ef', borderStrong: '#d4dbe4',
  accent: '#3863a8', accentText: '#ffffff', accentSoft: '#e8eff8', accentLine: '#cbdcef',
  accentDeep: '#2c4f8a',
  good: '#2f8a63', goodSoft: '#e2f1ea',
  warn: '#c08a2e', warnSoft: '#f6ecd8',
  pink: '#a8538f', pinkSoft: '#f5e6f0',
  fontDisplay: "'Space Grotesk', system-ui, sans-serif",
  fontBody: "'Plus Jakarta Sans', system-ui, sans-serif",
  fontMono: "'Space Mono', ui-monospace, monospace",
  radius: 13, radiusSm: 9, radiusLg: 18, badgeRadius: 11,
  shadowSm: '0 1px 2px rgba(20,30,45,0.05)',
  shadow: '0 1px 2px rgba(20,30,45,0.05), 0 6px 18px rgba(20,30,45,0.05)',
  shadowLg: '0 8px 30px rgba(20,30,45,0.12), 0 2px 6px rgba(20,30,45,0.06)',
  headingLetter: '-0.02em',
};

const ThemeContext = createContext(BASE_THEME);
const useT = () => useContext(ThemeContext);

/* Subject color accents — used for tags/badges across the app */
const SUBJECT_COLORS = {
  Math:        { c: '#3863a8', soft: '#e8eff8' },
  Science:     { c: '#2f8a63', soft: '#e2f1ea' },
  ELA:         { c: '#a8538f', soft: '#f5e6f0' },
  Reading:     { c: '#a8538f', soft: '#f5e6f0' },
  'Social Studies': { c: '#c0762e', soft: '#f6ecd8' },
  History:     { c: '#c0762e', soft: '#f6ecd8' },
  Geography:   { c: '#2b8a8a', soft: '#dff0f0' },
  Art:         { c: '#b05050', soft: '#f6e3e0' },
};
const subjectColor = (s) => SUBJECT_COLORS[s] || { c: '#6a7585', soft: '#eef2f6' };

/* ------------------------- localStorage helper ------------------------ */
const store = {
  get(k, fallback) {
    try { const v = localStorage.getItem('hsk.' + k); return v == null ? fallback : JSON.parse(v); }
    catch (e) { return fallback; }
  },
  set(k, v) { try { localStorage.setItem('hsk.' + k, JSON.stringify(v)); } catch (e) {} },
};

const uid = () => Math.random().toString(36).slice(2, 9);
const cx = (...a) => a.filter(Boolean).join(' ');

/* -------------------------- Icon component ---------------------------- */
function Icon({ name, size = 20, stroke = 'currentColor', sw = 1.7, style }) {
  const c = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke,
    strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round', style };
  const P = {
    worksheet: <><rect x="5" y="3" width="14" height="18" rx="2"/><line x1="8.5" y1="8" x2="15.5" y2="8"/><line x1="8.5" y1="12" x2="15.5" y2="12"/><line x1="8.5" y1="16" x2="13" y2="16"/></>,
    quiz: <><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .8-1 1.7"/><line x1="12" y1="16.5" x2="12" y2="16.6"/></>,
    wordsearch: <><rect x="4" y="4" width="16" height="16" rx="2"/><line x1="4" y1="9.3" x2="20" y2="9.3"/><line x1="4" y1="14.6" x2="20" y2="14.6"/><line x1="9.3" y1="4" x2="9.3" y2="20"/><line x1="14.6" y1="4" x2="14.6" y2="20"/></>,
    vocab: <><path d="M7 18 11 6l4 12"/><line x1="8.3" y1="14" x2="13.7" y2="14"/><line x1="17" y1="9" x2="17" y2="18"/></>,
    reading: <><path d="M12 6c-1.8-1.3-4-1.8-6.5-1.5V18c2.5-.3 4.7.2 6.5 1.5 1.8-1.3 4-1.8 6.5-1.5V4.5C16 4.2 13.8 4.7 12 6Z"/><line x1="12" y1="6" x2="12" y2="19.5"/></>,
    place: <><path d="M12 21c4-4 6.5-7 6.5-10.2A6.5 6.5 0 0 0 5.5 10.8C5.5 14 8 17 12 21Z"/><circle cx="12" cy="10.5" r="2.2"/></>,
    library: <><rect x="4" y="4" width="6" height="16" rx="1"/><rect x="14" y="4" width="6" height="16" rx="1"/></>,
    share: <><circle cx="6" cy="12" r="2.4"/><circle cx="17" cy="6" r="2.4"/><circle cx="17" cy="18" r="2.4"/><line x1="8.1" y1="10.9" x2="14.9" y2="7.1"/><line x1="8.1" y1="13.1" x2="14.9" y2="16.9"/></>,
    home: <><path d="M4 11 12 4l8 7"/><path d="M6 9.5V20h12V9.5"/></>,
    search: <><circle cx="11" cy="11" r="6.5"/><line x1="16" y1="16" x2="20" y2="20"/></>,
    plus: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    spark: <><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><path d="M6.3 6.3 8.4 8.4M15.6 15.6 17.7 17.7M17.7 6.3 15.6 8.4M8.4 15.6 6.3 17.7"/></>,
    print: <><path d="M7 9V4h10v5"/><rect x="5" y="9" width="14" height="7" rx="1.5"/><path d="M8 16h8v4H8z"/><line x1="16" y1="12" x2="16.01" y2="12"/></>,
    download: <><path d="M12 4v11"/><path d="M8 11l4 4 4-4"/><path d="M5 19h14"/></>,
    edit: <><path d="M5 19h14"/><path d="M14 5.5l3.5 3.5L9 17.5l-4 1 1-4 8-9Z"/></>,
    save: <><path d="M5 5h11l3 3v11H5z"/><path d="M8 5v5h7"/><rect x="9" y="14" width="6" height="5"/></>,
    check: <><path d="M5 12.5 10 17l9-10"/></>,
    chevR: <><path d="M9 6l6 6-6 6"/></>,
    chevL: <><path d="M15 6l-6 6 6 6"/></>,
    chevD: <><path d="M6 9l6 6 6-6"/></>,
    close: <><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></>,
    menu: <><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></>,
    locate: <><circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></>,
    clock: <><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></>,
    pin: <><path d="M12 21c4-4 6.5-7 6.5-10.2A6.5 6.5 0 0 0 5.5 10.8C5.5 14 8 17 12 21Z"/><circle cx="12" cy="10.5" r="2.2"/></>,
    ticket: <><path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2 2 2 0 0 0 0 4 2 2 0 0 1-2 2H6a2 2 0 0 1-2-2 2 2 0 0 0 0-4Z"/><line x1="13" y1="6" x2="13" y2="18" strokeDasharray="1.5 2.5"/></>,
    star: <><path d="M12 4l2.3 4.8 5.2.7-3.8 3.6.9 5.2L12 16.3 7.4 18.6l.9-5.2L4.5 9.8l5.2-.7Z"/></>,
    users: <><circle cx="9" cy="8" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><path d="M16 5.5a3 3 0 0 1 0 5.8"/><path d="M20.5 19a5.5 5.5 0 0 0-3.5-5.1"/></>,
    book: <><path d="M5 4h9a3 3 0 0 1 3 3v13a2.5 2.5 0 0 0-2.5-2.5H5Z"/><path d="M5 4v13.5"/></>,
    tag: <><path d="M4 4h7l9 9-7 7-9-9V4Z"/><circle cx="8" cy="8" r="1.3"/></>,
    grid: <><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></>,
    list: <><line x1="8" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="20" y2="12"/><line x1="8" y1="18" x2="20" y2="18"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/></>,
    link: <><path d="M9 15l6-6"/><path d="M11 7l1.5-1.5a3.5 3.5 0 0 1 5 5L16 12"/><path d="M13 17l-1.5 1.5a3.5 3.5 0 0 1-5-5L8 12"/></>,
    copy: <><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></>,
    trash: <><path d="M5 7h14"/><path d="M9 7V5h6v2"/><path d="M7 7l1 12h8l1-12"/></>,
    sliders: <><line x1="4" y1="8" x2="20" y2="8"/><circle cx="9" cy="8" r="2.2"/><line x1="4" y1="16" x2="20" y2="16"/><circle cx="15" cy="16" r="2.2"/></>,
    sparkles: <><path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6Z"/><path d="M18 14l.8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8Z"/></>,
    refresh: <><path d="M19 8a7 7 0 0 0-12-2L4 9"/><path d="M5 16a7 7 0 0 0 12 2l3-3"/><path d="M4 5v4h4M20 19v-4h-4"/></>,
    arrowL: <><line x1="19" y1="12" x2="5" y2="12"/><path d="M11 6l-6 6 6 6"/></>,
    arrowR: <><line x1="5" y1="12" x2="19" y2="12"/><path d="M13 6l6 6-6 6"/></>,
    leaf: <><path d="M5 19c0-8 6-13 14-13 0 8-5 14-13 14-1 0-1-1-1-1Z"/><path d="M9 15c2-2.5 4.5-4 8-5"/></>,
    flask: <><path d="M9 3h6M10 3v6l-4.5 8a2 2 0 0 0 1.8 3h9.4a2 2 0 0 0 1.8-3L14 9V3"/><line x1="8" y1="15" x2="16" y2="15"/></>,
    globe: <><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.4 2.5 14.6 0 17M12 3.5c-2.5 2.4-2.5 14.6 0 17"/></>,
    palette: <><path d="M12 4a8 8 0 1 0 0 16c1.4 0 1.8-1 1.2-2-.6-1.1.2-2 1.3-2H17a3 3 0 0 0 3-3 8 8 0 0 0-8-7Z"/><circle cx="8.5" cy="11" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="11" r="1"/></>,
    bolt: <><path d="M13 3 5 13h5l-1 8 8-11h-5l1-7Z"/></>,
    calendar: <><rect x="4" y="5" width="16" height="16" rx="2"/><line x1="4" y1="9.5" x2="20" y2="9.5"/><line x1="8" y1="3" x2="8" y2="6"/><line x1="16" y1="3" x2="16" y2="6"/></>,
    dollar: <><line x1="12" y1="3" x2="12" y2="21"/><path d="M16 7.5C16 6 14.2 5 12 5S8 6 8 8s2 2.6 4 3 4 1.2 4 3.2-1.8 3-4 3-4-1-4-2.5"/></>,
    map: <><path d="M9 4 4 6v14l5-2 6 2 5-2V4l-5 2-6-2Z"/><line x1="9" y1="4" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="20"/></>,
    heart: <><path d="M12 20s-7-4.3-7-9.3A3.7 3.7 0 0 1 12 8a3.7 3.7 0 0 1 7-2.7"/></>,
    folder: <><path d="M4 7a2 2 0 0 1 2-2h3.5l2 2H18a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"/></>,
    flag: <><path d="M6 3v18"/><path d="M6 4h11l-2 3 2 3H6"/></>,
  };
  return <svg {...c}>{P[name] || <circle cx="12" cy="12" r="8"/>}</svg>;
}

/* The geometric/colored badge for a generator type */
const GEN_META = {
  worksheet: { icon: 'worksheet', label: 'Worksheet', color: 'Math' },
  quiz: { icon: 'quiz', label: 'Quiz', color: 'Science' },
  wordsearch: { icon: 'wordsearch', label: 'Word Search', color: 'ELA' },
  vocab: { icon: 'vocab', label: 'Vocabulary', color: 'Social Studies' },
  reading: { icon: 'reading', label: 'Reading Passage', color: 'Geography' },
  unitstudy: { icon: 'place', label: 'Unit Study', color: 'Art' },
};

/* ============================ UI PRIMITIVES =========================== */
function Button({ children, variant = 'primary', size = 'md', icon, iconR, full, onClick, disabled, style }) {
  const t = useT();
  const [hover, setHover] = useState(false);
  const sizes = {
    sm: { pad: '7px 12px', fs: 13, ic: 15, gap: 6 },
    md: { pad: '10px 16px', fs: 14, ic: 17, gap: 8 },
    lg: { pad: '13px 22px', fs: 15.5, ic: 19, gap: 9 },
  }[size];
  const variants = {
    primary: { bg: hover ? t.accentDeep : t.accent, color: t.accentText, border: 'transparent', shadow: t.shadowSm },
    soft: { bg: hover ? t.accentLine : t.accentSoft, color: t.accentDeep, border: 'transparent', shadow: 'none' },
    ghost: { bg: hover ? t.surfaceAlt : 'transparent', color: t.text, border: 'transparent', shadow: 'none' },
    outline: { bg: hover ? t.surfaceAlt : t.surface, color: t.text, border: t.borderStrong, shadow: 'none' },
    danger: { bg: hover ? '#f4dcdc' : '#f8eaea', color: '#b04141', border: 'transparent', shadow: 'none' },
  }[variant];
  return (
    <button onClick={disabled ? undefined : onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: full ? 'flex' : 'inline-flex', width: full ? '100%' : undefined,
        alignItems: 'center', justifyContent: 'center', gap: sizes.gap, padding: sizes.pad,
        background: variants.bg, color: variants.color, border: `1px solid ${variants.border}`,
        borderRadius: t.radiusSm, fontFamily: t.fontBody, fontWeight: 600, fontSize: sizes.fs,
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, boxShadow: variants.shadow,
        transition: 'background .14s, box-shadow .14s', whiteSpace: 'nowrap', lineHeight: 1.1, ...style }}>
      {icon && <Icon name={icon} size={sizes.ic} />}{children}{iconR && <Icon name={iconR} size={sizes.ic} />}
    </button>
  );
}

function IconButton({ name, onClick, size = 'md', title, active, style }) {
  const t = useT();
  const [hover, setHover] = useState(false);
  const d = size === 'sm' ? 30 : 36;
  return (
    <button title={title} onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ width: d, height: d, display: 'grid', placeItems: 'center', borderRadius: t.radiusSm,
        background: active ? t.accentSoft : hover ? t.surfaceAlt : 'transparent',
        color: active ? t.accent : t.textMuted, border: 'none', cursor: 'pointer', transition: 'background .14s', ...style }}>
      <Icon name={name} size={size === 'sm' ? 17 : 19} />
    </button>
  );
}

function Card({ children, pad = 18, hover, onClick, style }) {
  const t = useT();
  const [h, setH] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ background: t.surface, border: `1px solid ${(hover && h) ? t.borderStrong : t.border}`,
        borderRadius: t.radius, boxShadow: (hover && h) ? t.shadow : t.shadowSm, padding: pad,
        cursor: onClick ? 'pointer' : 'default', transition: 'box-shadow .15s, border-color .15s, transform .15s',
        transform: (hover && h) ? 'translateY(-2px)' : 'none', ...style }}>
      {children}
    </div>
  );
}

function Badge({ children, color, soft, icon, style }) {
  const t = useT();
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px',
      borderRadius: 999, background: soft || t.surfaceAlt, color: color || t.textMuted,
      fontSize: 11.5, fontWeight: 600, fontFamily: t.fontBody, whiteSpace: 'nowrap', ...style }}>
      {icon && <Icon name={icon} size={12} />}{children}
    </span>
  );
}

function GenBadge({ type, size = 40 }) {
  const t = useT();
  const m = GEN_META[type] || GEN_META.worksheet;
  const col = subjectColor(m.color);
  return (
    <div style={{ width: size, height: size, borderRadius: t.badgeRadius, background: col.soft,
      color: col.c, display: 'grid', placeItems: 'center', flex: `0 0 ${size}px` }}>
      <Icon name={m.icon} size={size * 0.52} stroke={col.c} />
    </div>
  );
}

/* Form field wrapper */
function Field({ label, hint, children, style }) {
  const t = useT();
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && <span style={{ fontSize: 12.5, fontWeight: 600, color: t.text }}>{label}</span>}
      {children}
      {hint && <span style={{ fontSize: 11.5, color: t.textFaint }}>{hint}</span>}
    </label>
  );
}

function TextInput({ value, onChange, placeholder, icon, mono, style }) {
  const t = useT();
  const [foc, setFoc] = useState(false);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: t.surface,
      border: `1px solid ${foc ? t.accent : t.border}`, borderRadius: t.radiusSm, padding: '0 11px',
      boxShadow: foc ? `0 0 0 3px ${t.accentSoft}` : 'none', transition: 'border-color .14s, box-shadow .14s', ...style }}>
      {icon && <Icon name={icon} size={16} stroke={t.textFaint} />}
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
        style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', padding: '10px 0',
          fontFamily: mono ? t.fontMono : t.fontBody, fontSize: 14, color: t.text }} />
    </div>
  );
}

function TextArea({ value, onChange, placeholder, rows = 3, style }) {
  const t = useT();
  const [foc, setFoc] = useState(false);
  return (
    <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={rows}
      onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
      style={{ border: `1px solid ${foc ? t.accent : t.border}`, borderRadius: t.radiusSm, padding: '10px 11px',
        fontFamily: t.fontBody, fontSize: 14, color: t.text, outline: 'none', resize: 'vertical',
        boxShadow: foc ? `0 0 0 3px ${t.accentSoft}` : 'none', background: t.surface, ...style }} />
  );
}

function Select({ value, onChange, options, style }) {
  const t = useT();
  return (
    <div style={{ position: 'relative', ...style }}>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        style={{ width: '100%', appearance: 'none', border: `1px solid ${t.border}`, borderRadius: t.radiusSm,
          padding: '10px 34px 10px 11px', fontFamily: t.fontBody, fontSize: 14, color: t.text,
          background: t.surface, cursor: 'pointer', outline: 'none' }}>
        {options.map((o) => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}
      </select>
      <div style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: t.textFaint }}>
        <Icon name="chevD" size={16} />
      </div>
    </div>
  );
}

/* Segmented control */
function Segmented({ value, onChange, options, size = 'md' }) {
  const t = useT();
  return (
    <div style={{ display: 'inline-flex', background: t.surfaceSunken, borderRadius: t.radiusSm, padding: 3, gap: 2,
      border: `1px solid ${t.border}` }}>
      {options.map((o) => {
        const val = o.value ?? o, lab = o.label ?? o, on = val === value;
        return (
          <button key={val} onClick={() => onChange(val)}
            style={{ padding: size === 'sm' ? '5px 11px' : '7px 14px', border: 'none', cursor: 'pointer',
              borderRadius: t.radiusSm - 3, background: on ? t.surface : 'transparent', color: on ? t.text : t.textMuted,
              fontFamily: t.fontBody, fontWeight: 600, fontSize: size === 'sm' ? 12.5 : 13.5, whiteSpace: 'nowrap',
              boxShadow: on ? t.shadowSm : 'none', transition: 'background .14s, color .14s',
              display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            {o.icon && <Icon name={o.icon} size={15} />}{lab}
          </button>
        );
      })}
    </div>
  );
}

/* Chips that toggle (multi or single) */
function ChipToggle({ label, on, onClick, icon }) {
  const t = useT();
  return (
    <button onClick={onClick} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 13px',
      borderRadius: 999, cursor: 'pointer', fontFamily: t.fontBody, fontWeight: 600, fontSize: 13,
      border: `1px solid ${on ? t.accent : t.border}`, background: on ? t.accentSoft : t.surface,
      color: on ? t.accentDeep : t.textMuted, transition: 'all .14s', whiteSpace: 'nowrap' }}>
      {icon && <Icon name={icon} size={14} />}{label}
      {on && <Icon name="check" size={13} />}
    </button>
  );
}

function Stepper({ value, onChange, min = 1, max = 40, step = 1 }) {
  const t = useT();
  const btn = (d, ic) => (
    <button onClick={() => onChange(Math.max(min, Math.min(max, value + d)))}
      style={{ width: 34, height: 38, display: 'grid', placeItems: 'center', border: 'none', cursor: 'pointer',
        background: t.surface, color: t.textMuted }}><Icon name={ic} size={15} /></button>
  );
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', border: `1px solid ${t.border}`, borderRadius: t.radiusSm, overflow: 'hidden' }}>
      {btn(-step, 'chevL')}
      <div style={{ minWidth: 40, textAlign: 'center', fontFamily: t.fontMono, fontSize: 14, fontWeight: 700, color: t.text }}>{value}</div>
      {btn(step, 'chevR')}
    </div>
  );
}

/* Modal */
function Modal({ open, onClose, children, width = 460, title }) {
  const t = useT();
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    if (open) window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(20,30,45,0.4)', backdropFilter: 'blur(3px)',
      display: 'grid', placeItems: 'center', zIndex: 200, padding: 20, animation: 'hskFade .15s ease' }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width, maxWidth: '100%', maxHeight: '90vh', overflow: 'auto',
        background: t.surface, borderRadius: t.radiusLg, boxShadow: t.shadowLg, animation: 'hskPop .18s cubic-bezier(.2,.8,.3,1)' }}>
        {title && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 20px 0' }}>
            <h3 style={{ margin: 0, fontFamily: t.fontDisplay, fontSize: 17, fontWeight: 600, letterSpacing: t.headingLetter, color: t.text }}>{title}</h3>
            <IconButton name="close" size="sm" onClick={onClose} />
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

/* Toast */
function Toast({ toast }) {
  const t = useT();
  if (!toast) return null;
  return (
    <div style={{ position: 'fixed', bottom: 26, left: '50%', transform: 'translateX(-50%)', zIndex: 300,
      display: 'flex', alignItems: 'center', gap: 10, background: t.text, color: '#fff', padding: '11px 18px',
      borderRadius: 999, boxShadow: t.shadowLg, fontFamily: t.fontBody, fontWeight: 600, fontSize: 13.5,
      animation: 'hskToast .25s cubic-bezier(.2,.8,.3,1)' }}>
      <Icon name={toast.icon || 'check'} size={16} stroke={t.good === toast.color ? '#7fe0b3' : '#9fc0f0'} />
      {toast.msg}
    </div>
  );
}

/* Loading shimmer line */
function GenLoader({ label = 'Generating…' }) {
  const t = useT();
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 40 }}>
      <div style={{ position: 'relative', width: 54, height: 54 }}>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `3px solid ${t.accentSoft}` }} />
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `3px solid transparent`,
          borderTopColor: t.accent, animation: 'hskSpin .8s linear infinite' }} />
        <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: t.accent }}>
          <Icon name="sparkles" size={22} />
        </div>
      </div>
      <div style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 14.5, color: t.text }}>{label}</div>
      <div style={{ display: 'flex', gap: 5 }}>
        {[0, 1, 2].map((i) => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: t.accent,
          animation: `hskBounce 1s ${i * 0.15}s infinite ease-in-out` }} />)}
      </div>
    </div>
  );
}

/* Section heading */
function SectionTitle({ children, sub, action }) {
  const t = useT();
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12, marginBottom: 12 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, minWidth: 0 }}>
        <h2 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, letterSpacing: t.headingLetter, color: t.text, whiteSpace: 'nowrap' }}>{children}</h2>
        {sub && <span style={{ color: t.textMuted, fontSize: 12.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sub}</span>}
      </div>
      {action}
    </div>
  );
}

/* Striped image placeholder */
function Placeholder({ label, height = 120, radius, style }) {
  const t = useT();
  return (
    <div style={{ height, borderRadius: radius ?? t.radiusSm, border: `1px solid ${t.border}`, overflow: 'hidden',
      position: 'relative', background: `repeating-linear-gradient(135deg, ${t.surfaceAlt}, ${t.surfaceAlt} 10px, ${t.surfaceSunken} 10px, ${t.surfaceSunken} 20px)`,
      display: 'flex', alignItems: 'flex-end', padding: 10, ...style }}>
      <span style={{ fontFamily: t.fontMono, fontSize: 10.5, color: t.textFaint, background: t.surface, padding: '2px 7px', borderRadius: 5, border: `1px solid ${t.border}` }}>{label}</span>
    </div>
  );
}

/* Global keyframes + base */
(function injectCSS() {
  if (document.getElementById('hsk-css')) return;
  const s = document.createElement('style');
  s.id = 'hsk-css';
  s.textContent = `
    @keyframes hskSpin { to { transform: rotate(360deg); } }
    @keyframes hskBounce { 0%,80%,100% { transform: scale(.5); opacity:.4 } 40% { transform: scale(1); opacity:1 } }
    @keyframes hskFade { from { opacity: 0 } to { opacity: 1 } }
    @keyframes hskPop { from { opacity: 0; transform: translateY(8px) scale(.98) } to { opacity:1; transform: none } }
    @keyframes hskToast { from { opacity: 0; transform: translate(-50%, 12px) } to { opacity:1; transform: translate(-50%,0) } }
    @keyframes hskRise { from { opacity: 0; transform: translateY(10px) } to { opacity:1; transform: none } }
    .hsk-rise { animation: hskRise .35s cubic-bezier(.2,.8,.3,1) both; }
    .hsk-scroll::-webkit-scrollbar { width: 9px; height: 9px; }
    .hsk-scroll::-webkit-scrollbar-thumb { background: #d4dbe4; border-radius: 6px; border: 2px solid transparent; background-clip: padding-box; }
    .hsk-scroll::-webkit-scrollbar-track { background: transparent; }
    * { box-sizing: border-box; }
  `;
  document.head.appendChild(s);
})();

Object.assign(window, {
  BASE_THEME, ThemeContext, useT, SUBJECT_COLORS, subjectColor, store, uid, cx,
  Icon, GEN_META, Button, IconButton, Card, Badge, GenBadge, Field, TextInput, TextArea,
  Select, Segmented, ChipToggle, Stepper, Modal, Toast, GenLoader, SectionTitle, Placeholder,
  useState, useEffect, useRef, useContext, createContext, useCallback, useMemo,
});
