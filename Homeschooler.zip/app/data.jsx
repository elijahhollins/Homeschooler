/* ===================================================================== *
 *  data.jsx — HomeschoolKit content engine (simulated AI generation)
 *  Curated knowledge base + procedural generators. Exports to window.
 * ===================================================================== */

/* --------------------------- Knowledge base --------------------------- */
/* Each topic: vocab, facts, questions (mcq), passage, words (search),
   bigIdeas, activities, discussion. Used by all generators. */
const KB = {
  ocean_animals: {
    title: 'Ocean Animals', subject: 'Science', emoji: '🌊', topicWord: 'ocean animals',
    vocab: [
      { word: 'habitat', pos: 'n.', def: 'The natural home of an animal or plant.', sentence: 'A coral reef is the habitat of many fish.' },
      { word: 'gills', pos: 'n.', def: 'Body parts that let fish breathe underwater.', sentence: 'Fish use their gills to take oxygen from water.' },
      { word: 'predator', pos: 'n.', def: 'An animal that hunts other animals for food.', sentence: 'The shark is a fast predator.' },
      { word: 'camouflage', pos: 'n.', def: 'Coloring that helps an animal blend in.', sentence: 'An octopus uses camouflage to hide.' },
      { word: 'tentacle', pos: 'n.', def: 'A long, bendy arm used to grab or feel.', sentence: 'A jellyfish stings with its tentacles.' },
      { word: 'mammal', pos: 'n.', def: 'A warm-blooded animal that breathes air.', sentence: 'A dolphin is a mammal, not a fish.' },
      { word: 'school', pos: 'n.', def: 'A large group of fish swimming together.', sentence: 'The school of sardines moved as one.' },
      { word: 'reef', pos: 'n.', def: 'A ridge of coral near the ocean surface.', sentence: 'The reef was full of colorful life.' },
    ],
    facts: [
      'A dolphin is a mammal and must come to the surface to breathe air.',
      'An octopus has three hearts and blue blood.',
      'Sea turtles can hold their breath for hours while resting.',
      'A jellyfish has no brain, heart, or bones.',
      'Sharks can have thousands of teeth over their lifetime.',
      'Clownfish live safely among the stinging tentacles of sea anemones.',
    ],
    questions: [
      { q: 'Which ocean animal is a mammal?', choices: ['Shark', 'Dolphin', 'Tuna', 'Octopus'], answer: 1 },
      { q: 'What do fish use to breathe underwater?', choices: ['Lungs', 'Gills', 'Fins', 'Scales'], answer: 1 },
      { q: 'How does an octopus hide from predators?', choices: ['It swims fast', 'It uses camouflage', 'It makes noise', 'It glows'], answer: 1 },
      { q: 'A group of fish swimming together is called a…', choices: ['Herd', 'Flock', 'School', 'Pack'], answer: 2 },
      { q: 'How many hearts does an octopus have?', choices: ['One', 'Two', 'Three', 'Four'], answer: 2 },
      { q: 'Where do clownfish live safely?', choices: ['In sea anemones', 'In caves', 'On the sand', 'In seaweed only'], answer: 0 },
      { q: 'What is a reef mostly made of?', choices: ['Sand', 'Rock', 'Coral', 'Plastic'], answer: 2 },
      { q: 'Which animal must surface to breathe air?', choices: ['Tuna', 'Sea turtle', 'Eel', 'Crab'], answer: 1 },
    ],
    passage: [
      'The ocean is the largest habitat on Earth, and it is home to millions of different animals. From the sunny water near the surface to the dark, cold water far below, sea creatures have found amazing ways to survive.',
      'Many ocean animals are fish. Fish breathe by pulling water over their gills, which take in oxygen. Their fins help them steer, and their tails push them forward. Some fish, like sardines, swim together in a huge group called a school. Moving together helps protect them from predators.',
      'Not every animal in the sea is a fish. Dolphins and whales are mammals. Like us, they breathe air, so they must swim to the surface for a breath. An octopus is not a fish either. It has eight arms, three hearts, and can change color to camouflage itself and disappear against the rocks.',
      'Coral reefs are some of the busiest places in the ocean. A reef is built by tiny animals called coral, and it gives food and shelter to thousands of species. Protecting reefs and keeping the water clean helps all ocean animals stay healthy.',
    ],
    words: ['DOLPHIN', 'OCTOPUS', 'SHARK', 'CORAL', 'JELLYFISH', 'TURTLE', 'WHALE', 'CRAB', 'GILLS', 'REEF', 'STINGRAY', 'SEAHORSE'],
    bigIdeas: [
      'The ocean is a habitat with many zones, from sunlit shallows to the deep sea.',
      'Animals have body parts and behaviors adapted to survive underwater.',
      'Fish, mammals, and invertebrates all live in the ocean in different ways.',
      'Healthy reefs and clean water keep ocean food webs in balance.',
    ],
    activities: [
      'Sort animal cards into fish, mammals, and invertebrates.',
      'Build a shoebox diorama of a coral reef habitat.',
      'Measure out the length of a blue whale (30 m) with sidewalk chalk.',
      'Keep an "ocean journal" sketching three animals you saw on your visit.',
    ],
    discussion: [
      'Why do you think dolphins need to come to the surface?',
      'How does camouflage help an animal survive?',
      'What might happen to reef animals if the water became polluted?',
    ],
  },

  solar_system: {
    title: 'The Solar System', subject: 'Science', emoji: '🪐', topicWord: 'the solar system',
    vocab: [
      { word: 'orbit', pos: 'n.', def: 'The curved path an object takes around a star or planet.', sentence: 'Earth takes one year to complete its orbit.' },
      { word: 'planet', pos: 'n.', def: 'A large round object that orbits a star.', sentence: 'Jupiter is the largest planet.' },
      { word: 'gravity', pos: 'n.', def: 'A force that pulls objects toward each other.', sentence: 'Gravity keeps the planets near the Sun.' },
      { word: 'crater', pos: 'n.', def: 'A bowl-shaped hole made by an impact.', sentence: 'The Moon is covered in craters.' },
      { word: 'asteroid', pos: 'n.', def: 'A small rocky object orbiting the Sun.', sentence: 'An asteroid belt lies between Mars and Jupiter.' },
      { word: 'rotate', pos: 'v.', def: 'To spin around in place.', sentence: 'Earth rotates once every 24 hours.' },
      { word: 'star', pos: 'n.', def: 'A huge ball of hot, glowing gas.', sentence: 'The Sun is the closest star to Earth.' },
      { word: 'moon', pos: 'n.', def: 'A natural object that orbits a planet.', sentence: 'Mars has two small moons.' },
    ],
    facts: [
      'The Sun is a star, and it holds the solar system together with its gravity.',
      'A year on Earth is the time it takes to orbit the Sun once.',
      'A day is the time it takes a planet to rotate once.',
      'Jupiter is so big that more than 1,000 Earths could fit inside it.',
      'The Moon has no air, so footprints left by astronauts are still there.',
      'Saturn is famous for its bright rings made of ice and rock.',
    ],
    questions: [
      { q: 'What is at the center of our solar system?', choices: ['Earth', 'The Moon', 'The Sun', 'Jupiter'], answer: 2 },
      { q: 'What force keeps planets orbiting the Sun?', choices: ['Magnetism', 'Gravity', 'Wind', 'Heat'], answer: 1 },
      { q: 'Which planet is the largest?', choices: ['Mars', 'Earth', 'Jupiter', 'Venus'], answer: 2 },
      { q: 'A planet spinning once equals one…', choices: ['Year', 'Day', 'Month', 'Orbit'], answer: 1 },
      { q: 'What are the Moon\u2019s bowl-shaped holes called?', choices: ['Craters', 'Seas', 'Rings', 'Domes'], answer: 0 },
      { q: 'Which planet is known for its rings?', choices: ['Mercury', 'Saturn', 'Earth', 'Mars'], answer: 1 },
      { q: 'An asteroid belt lies between Mars and…', choices: ['Earth', 'Jupiter', 'Saturn', 'Venus'], answer: 1 },
      { q: 'The Sun is actually a…', choices: ['Planet', 'Moon', 'Star', 'Comet'], answer: 2 },
    ],
    passage: [
      'Our solar system is a family of planets, moons, and other objects that all travel around one star: the Sun. The Sun is so large and powerful that its gravity keeps everything nearby moving in a path called an orbit.',
      'There are eight planets. The four closest to the Sun \u2014 Mercury, Venus, Earth, and Mars \u2014 are small and rocky. The four farthest \u2014 Jupiter, Saturn, Uranus, and Neptune \u2014 are giant balls of gas and ice. Jupiter is the biggest of them all.',
      'Planets do two things at once. They orbit the Sun, and they rotate, or spin. One spin of Earth gives us a day and a night. One full trip around the Sun gives us a year. Many planets also have moons that orbit them, just as our Moon orbits Earth.',
      'Between Mars and Jupiter floats a band of rocky asteroids. Far past Neptune, icy comets travel on long, looping paths. Scientists use telescopes and spacecraft to learn more about these distant neighbors every year.',
    ],
    words: ['SUN', 'EARTH', 'JUPITER', 'SATURN', 'ORBIT', 'GRAVITY', 'CRATER', 'COMET', 'MARS', 'MOON', 'ASTEROID', 'PLANET'],
    bigIdeas: [
      'The Sun\u2019s gravity holds the solar system together.',
      'Planets both orbit the Sun and rotate on their own axis.',
      'Rotation makes day and night; orbit makes a year.',
      'Rocky inner planets and giant outer planets are very different worlds.',
    ],
    activities: [
      'Build a scale model of the planets using fruit and a ball for the Sun.',
      'Make a flip-book showing the phases of the Moon.',
      'Use a flashlight and globe to act out day and night.',
      'Design a travel poster for your favorite planet.',
    ],
    discussion: [
      'Why is it always the Sun\u2019s gravity that keeps the planets close?',
      'How are the inner planets different from the outer planets?',
      'What would a "day" feel like on a planet that spins very slowly?',
    ],
  },

  dinosaurs: {
    title: 'Dinosaurs & Fossils', subject: 'Science', emoji: '🦕', topicWord: 'dinosaurs',
    vocab: [
      { word: 'fossil', pos: 'n.', def: 'The preserved remains or trace of a living thing.', sentence: 'The fossil was buried in rock for millions of years.' },
      { word: 'extinct', pos: 'adj.', def: 'No longer existing anywhere on Earth.', sentence: 'Dinosaurs became extinct long ago.' },
      { word: 'herbivore', pos: 'n.', def: 'An animal that eats only plants.', sentence: 'A herbivore like Triceratops ate leaves.' },
      { word: 'carnivore', pos: 'n.', def: 'An animal that eats meat.', sentence: 'T. rex was a fierce carnivore.' },
      { word: 'paleontologist', pos: 'n.', def: 'A scientist who studies fossils.', sentence: 'A paleontologist carefully digs up bones.' },
      { word: 'prehistoric', pos: 'adj.', def: 'From a time before written history.', sentence: 'Dinosaurs lived in prehistoric times.' },
      { word: 'skeleton', pos: 'n.', def: 'The frame of bones inside a body.', sentence: 'The museum displayed a dinosaur skeleton.' },
      { word: 'excavate', pos: 'v.', def: 'To carefully dig something out of the ground.', sentence: 'Scientists excavate fossils with small tools.' },
    ],
    facts: [
      'Dinosaurs lived millions of years before humans existed.',
      'Fossils form when remains are slowly replaced by minerals in rock.',
      'Some dinosaurs ate only plants, while others hunted meat.',
      'Paleontologists study fossils to learn how dinosaurs lived.',
      'Birds are the living relatives of certain dinosaurs.',
      'A T. rex tooth could be as long as a banana.',
    ],
    questions: [
      { q: 'A scientist who studies fossils is a…', choices: ['Biologist', 'Paleontologist', 'Astronomer', 'Geologist'], answer: 1 },
      { q: 'An animal that eats only plants is a…', choices: ['Carnivore', 'Herbivore', 'Predator', 'Omnivore'], answer: 1 },
      { q: 'What does "extinct" mean?', choices: ['Very large', 'No longer existing', 'Very old', 'Asleep'], answer: 1 },
      { q: 'How do fossils form?', choices: ['Overnight', 'Remains turn to rock over time', 'By freezing', 'They are made by people'], answer: 1 },
      { q: 'Which living animals are related to dinosaurs?', choices: ['Lizards', 'Birds', 'Fish', 'Frogs'], answer: 1 },
      { q: 'T. rex was a…', choices: ['Herbivore', 'Carnivore', 'Plant', 'Fish'], answer: 1 },
      { q: 'To dig fossils out carefully is to…', choices: ['Excavate', 'Build', 'Paint', 'Melt'], answer: 0 },
      { q: 'Dinosaurs lived in times that were…', choices: ['Modern', 'Prehistoric', 'Future', 'Medieval'], answer: 1 },
    ],
    passage: [
      'Long before there were people, giant reptiles called dinosaurs ruled the Earth. They lived during prehistoric times, millions of years ago. We know about them today because of fossils \u2014 the hardened remains of bones, teeth, and even footprints left behind in rock.',
      'Dinosaurs came in many shapes and sizes. Some, like Triceratops, were herbivores that ate only plants. Others, like the mighty Tyrannosaurus rex, were carnivores that hunted other animals. The largest dinosaurs were longer than a school bus, while some were no bigger than a chicken.',
      'Scientists called paleontologists search for fossils buried in the ground. When they find one, they excavate it slowly with small brushes and tools so the fragile pieces are not broken. Back at the museum, they fit the bones together to build a skeleton we can all see.',
      'Although dinosaurs are extinct, they did not vanish completely. Scientists have discovered that birds are the living relatives of certain dinosaurs. So the next time you see a sparrow, you are looking at a distant cousin of the dinosaurs!',
    ],
    words: ['FOSSIL', 'TREX', 'BONES', 'EXTINCT', 'HERBIVORE', 'SKELETON', 'DIG', 'PREHISTORIC', 'TRICERATOPS', 'CLAW', 'EGG', 'AMBER'],
    bigIdeas: [
      'Fossils are evidence of life from the distant past.',
      'Dinosaurs were diverse \u2014 different sizes, diets, and bodies.',
      'Paleontologists use careful methods to uncover and study fossils.',
      'Living things change over time; birds descend from dinosaurs.',
    ],
    activities: [
      'Make a "fossil" by pressing a shell or leaf into clay.',
      'Sort dinosaur cards into herbivores and carnivores.',
      'Excavate toy bones from a sand tray using a brush.',
      'Measure and tape out the length of a T. rex (12 m) on the floor.',
    ],
    discussion: [
      'How can a footprint become a fossil?',
      'Why must paleontologists dig so slowly and carefully?',
      'What clues might tell us whether a dinosaur ate plants or meat?',
    ],
  },

  plants: {
    title: 'Plants & Photosynthesis', subject: 'Science', emoji: '🌱', topicWord: 'plants',
    vocab: [
      { word: 'photosynthesis', pos: 'n.', def: 'How plants make food from sunlight, water, and air.', sentence: 'Leaves carry out photosynthesis in the sun.' },
      { word: 'roots', pos: 'n.', def: 'The part of a plant that takes in water from soil.', sentence: 'The roots held the tree firmly in the ground.' },
      { word: 'chlorophyll', pos: 'n.', def: 'The green substance that captures sunlight.', sentence: 'Chlorophyll makes leaves look green.' },
      { word: 'pollinate', pos: 'v.', def: 'To carry pollen so a plant can make seeds.', sentence: 'Bees pollinate the flowers.' },
      { word: 'seed', pos: 'n.', def: 'The small part of a plant that can grow into a new plant.', sentence: 'She planted a seed in the soil.' },
      { word: 'stem', pos: 'n.', def: 'The part that holds up the plant and carries water.', sentence: 'Water travels up the stem to the leaves.' },
      { word: 'germinate', pos: 'v.', def: 'To begin to grow from a seed.', sentence: 'The bean started to germinate after three days.' },
      { word: 'nutrient', pos: 'n.', def: 'Something living things need to grow.', sentence: 'Roots pull nutrients from the soil.' },
    ],
    facts: [
      'Plants make their own food through photosynthesis.',
      'Roots take in water and nutrients from the soil.',
      'Chlorophyll gives leaves their green color and captures sunlight.',
      'Plants release the oxygen we breathe.',
      'Bees and other insects help pollinate flowers.',
      'A seed needs water, warmth, and air to germinate.',
    ],
    questions: [
      { q: 'How do plants make their food?', choices: ['By eating soil', 'Photosynthesis', 'By drinking only', 'From animals'], answer: 1 },
      { q: 'Which part takes in water from the soil?', choices: ['Leaves', 'Flowers', 'Roots', 'Petals'], answer: 2 },
      { q: 'What makes leaves green?', choices: ['Water', 'Chlorophyll', 'Sugar', 'Air'], answer: 1 },
      { q: 'What gas do plants release?', choices: ['Oxygen', 'Helium', 'Smoke', 'Nitrogen'], answer: 0 },
      { q: 'What do bees do for flowers?', choices: ['Eat them', 'Pollinate them', 'Cut them', 'Water them'], answer: 1 },
      { q: 'To start growing from a seed is to…', choices: ['Wilt', 'Germinate', 'Pollinate', 'Freeze'], answer: 1 },
      { q: 'Which part holds the plant up and carries water?', choices: ['Root', 'Stem', 'Seed', 'Petal'], answer: 1 },
      { q: 'A seed needs water, air, and…', choices: ['Warmth', 'Darkness', 'Salt', 'Noise'], answer: 0 },
    ],
    passage: [
      'Plants may look quiet and still, but they are hard at work making their own food. This amazing process is called photosynthesis. Using sunlight, water, and a gas from the air, the leaves of a plant create the sugar they need to grow.',
      'Every part of a plant has a job. The roots reach down into the soil to drink water and pull up nutrients. The stem holds the plant upright and carries water to the leaves. The leaves are like tiny kitchens, full of a green substance called chlorophyll that captures sunlight.',
      'Many plants grow flowers so they can make seeds. To do this, they need help. Bees, butterflies, and other insects move from flower to flower and pollinate them. When a seed lands in good soil and gets water, warmth, and air, it will germinate and begin to grow.',
      'Plants do something wonderful for us, too. While they make their food, they release oxygen \u2014 the very air we breathe. Without plants, there would be no food and no fresh air for animals and people.',
    ],
    words: ['ROOTS', 'STEM', 'LEAF', 'SEED', 'SUNLIGHT', 'WATER', 'OXYGEN', 'POLLEN', 'FLOWER', 'SOIL', 'GROW', 'GREEN'],
    bigIdeas: [
      'Plants make their own food using sunlight (photosynthesis).',
      'Each plant part \u2014 roots, stem, leaves \u2014 has a special job.',
      'Plants reproduce with seeds, often helped by pollinators.',
      'Plants give off the oxygen that animals need.',
    ],
    activities: [
      'Sprout a bean seed in a clear cup and chart its growth.',
      'Label the parts of a real plant you find outside.',
      'Place celery in colored water to watch the stem carry it up.',
      'Press and dry leaves, then sort them by shape.',
    ],
    discussion: [
      'Why do you think leaves are green?',
      'What might happen to a plant kept in a dark room?',
      'How do bees help plants and people at the same time?',
    ],
  },

  zoo_animals: {
    title: 'Animals & Habitats', subject: 'Science', emoji: '🦁', topicWord: 'animals and their habitats',
    vocab: [
      { word: 'habitat', pos: 'n.', def: 'The natural home of an animal.', sentence: 'The savanna is a lion\u2019s habitat.' },
      { word: 'adaptation', pos: 'n.', def: 'A body part or behavior that helps an animal survive.', sentence: 'A giraffe\u2019s long neck is an adaptation.' },
      { word: 'mammal', pos: 'n.', def: 'A warm-blooded animal that feeds milk to its young.', sentence: 'An elephant is a mammal.' },
      { word: 'endangered', pos: 'adj.', def: 'At risk of no longer existing.', sentence: 'Many rhinos are endangered.' },
      { word: 'predator', pos: 'n.', def: 'An animal that hunts others for food.', sentence: 'The lion is a predator.' },
      { word: 'prey', pos: 'n.', def: 'An animal that is hunted for food.', sentence: 'Zebras are the prey of lions.' },
      { word: 'nocturnal', pos: 'adj.', def: 'Active mostly at night.', sentence: 'Owls are nocturnal.' },
      { word: 'species', pos: 'n.', def: 'A group of the same kind of living thing.', sentence: 'The zoo protects rare species.' },
    ],
    facts: [
      'An animal\u2019s habitat gives it food, water, and shelter.',
      'Adaptations help animals survive in their environment.',
      'Predators hunt prey, and both are part of a food chain.',
      'Some animals are nocturnal and sleep during the day.',
      'Zoos help protect endangered species.',
      'A giraffe\u2019s long neck helps it reach leaves high in trees.',
    ],
    questions: [
      { q: 'The natural home of an animal is its…', choices: ['Cage', 'Habitat', 'Nest only', 'Den only'], answer: 1 },
      { q: 'A body part that helps an animal survive is an…', choices: ['Adaptation', 'Accident', 'Illness', 'Instinct'], answer: 0 },
      { q: 'An animal that is hunted is called…', choices: ['Predator', 'Prey', 'Mammal', 'Herd'], answer: 1 },
      { q: 'An animal active at night is…', choices: ['Diurnal', 'Nocturnal', 'Extinct', 'Endangered'], answer: 1 },
      { q: 'Why is a giraffe\u2019s long neck useful?', choices: ['To swim', 'To reach high leaves', 'To dig', 'To fly'], answer: 1 },
      { q: 'Zoos help protect animals that are…', choices: ['Common', 'Endangered', 'Extinct', 'Tame'], answer: 1 },
      { q: 'A warm-blooded animal that feeds milk to its young is a…', choices: ['Reptile', 'Mammal', 'Fish', 'Bird'], answer: 1 },
      { q: 'Predator is to prey as hunter is to…', choices: ['Hunted', 'Helper', 'Friend', 'Plant'], answer: 0 },
    ],
    passage: [
      'Every animal has a place where it belongs \u2014 a home called a habitat. A habitat gives an animal the food, water, and shelter it needs. A polar bear\u2019s habitat is cold and icy, while a camel\u2019s habitat is hot and sandy. Each animal is suited to where it lives.',
      'The features that help an animal survive are called adaptations. A giraffe has a long neck to reach leaves high in the trees. A polar bear has thick fur to stay warm. A duck has webbed feet to swim. These special tools are passed down from parents to babies.',
      'In every habitat, animals are connected through food. Predators are animals that hunt, and prey are the animals they hunt. A lion is a predator, and a zebra is its prey. Some animals, called nocturnal animals, hunt or move around at night and sleep during the day.',
      'Sadly, some species are endangered, which means very few are left. Zoos and wildlife parks work to protect these animals, study them, and teach people how to help. By learning about animals and their habitats, we can help keep them safe for the future.',
    ],
    words: ['LION', 'ELEPHANT', 'GIRAFFE', 'HABITAT', 'PREDATOR', 'PREY', 'MAMMAL', 'TIGER', 'ZEBRA', 'MONKEY', 'PENGUIN', 'BEAR'],
    bigIdeas: [
      'Animals live in habitats that meet their needs.',
      'Adaptations help animals survive where they live.',
      'Predators and prey are linked in food chains.',
      'People can help protect endangered animals.',
    ],
    activities: [
      'Match animal cards to their habitats (desert, ocean, forest, arctic).',
      'Draw an animal and label two of its adaptations.',
      'Build a food chain with arrows from prey to predator.',
      'Pick one endangered animal and make a "save me" poster.',
    ],
    discussion: [
      'How is a polar bear\u2019s body suited to the cold?',
      'What might happen to prey animals if all the predators left?',
      'Why are zoos important for endangered species?',
    ],
  },

  american_revolution: {
    title: 'The American Revolution', subject: 'Social Studies', emoji: '🇺🇸', topicWord: 'the American Revolution',
    vocab: [
      { word: 'colony', pos: 'n.', def: 'A place ruled by a faraway country.', sentence: 'America began as thirteen colonies.' },
      { word: 'independence', pos: 'n.', def: 'Freedom to govern yourself.', sentence: 'The colonists wanted independence.' },
      { word: 'tax', pos: 'n.', def: 'Money people must pay to a government.', sentence: 'A new tax on tea made colonists angry.' },
      { word: 'patriot', pos: 'n.', def: 'A colonist who wanted freedom from Britain.', sentence: 'A patriot fought for independence.' },
      { word: 'liberty', pos: 'n.', def: 'The freedom to do as you choose.', sentence: 'They believed in liberty for all.' },
      { word: 'declaration', pos: 'n.', def: 'An official announcement.', sentence: 'The Declaration of Independence was signed in 1776.' },
      { word: 'militia', pos: 'n.', def: 'Ordinary citizens who serve as soldiers.', sentence: 'The town militia trained on the green.' },
      { word: 'represent', pos: 'v.', def: 'To speak or act for others.', sentence: 'No one was there to represent the colonists.' },
    ],
    facts: [
      'America began as thirteen British colonies.',
      'Colonists were angry about taxes they had no say in.',
      '"No taxation without representation" became a famous cry.',
      'The Declaration of Independence was adopted on July 4, 1776.',
      'George Washington led the colonial army.',
      'The war ended with the colonies winning their independence.',
    ],
    questions: [
      { q: 'How many colonies declared independence?', choices: ['Ten', 'Thirteen', 'Twenty', 'Seven'], answer: 1 },
      { q: 'What were colonists angry about?', choices: ['The weather', 'Taxes', 'Food', 'Schools'], answer: 1 },
      { q: 'When was the Declaration of Independence adopted?', choices: ['1492', '1620', '1776', '1812'], answer: 2 },
      { q: 'Who led the colonial army?', choices: ['Ben Franklin', 'George Washington', 'King George', 'Paul Revere'], answer: 1 },
      { q: 'A colonist who wanted freedom was a…', choices: ['Loyalist', 'Patriot', 'Soldier of Britain', 'Governor'], answer: 1 },
      { q: 'Independence means…', choices: ['Paying taxes', 'Governing yourself', 'Joining Britain', 'Building ships'], answer: 1 },
      { q: '"No taxation without…" what?', choices: ['Money', 'Representation', 'Trade', 'War'], answer: 1 },
      { q: 'A place ruled by a faraway country is a…', choices: ['Colony', 'City', 'County', 'Camp'], answer: 0 },
    ],
    passage: [
      'More than 250 years ago, America was not its own country. It was made up of thirteen colonies ruled by Britain, a powerful nation across the ocean. For many years the colonists were proud to be British, but slowly that began to change.',
      'The trouble started with taxes. Britain made the colonists pay taxes on things like tea and paper, yet the colonists had no one to represent them in the British government. "No taxation without representation!" they cried. They felt it was unfair to be taxed without a say.',
      'Anger grew into action. Colonists who wanted freedom were called patriots. They formed local militias \u2014 ordinary farmers and shopkeepers ready to fight. In 1776, leaders signed the Declaration of Independence, announcing that the colonies were now free and would govern themselves.',
      'A long war followed, led by General George Washington. It was hard and lasted for years, but in the end the colonists won their independence. The thirteen colonies became a brand-new nation: the United States of America.',
    ],
    words: ['COLONY', 'LIBERTY', 'TAX', 'PATRIOT', 'WASHINGTON', 'FREEDOM', 'MILITIA', 'BRITAIN', 'TEA', 'FLAG', 'WAR', 'REVOLUTION'],
    bigIdeas: [
      'Thirteen colonies were ruled by Britain from far away.',
      'Unfair taxes without representation sparked anger.',
      'Patriots declared independence in 1776.',
      'After a long war, a new nation was born.',
    ],
    activities: [
      'Make a timeline of key events from 1765 to 1783.',
      'Write your own "declaration" listing fair rules for your home.',
      'Design a flag for one of the thirteen colonies.',
      'Role-play a town meeting debating the tea tax.',
    ],
    discussion: [
      'Why did "no taxation without representation" feel so unfair?',
      'What does it take for a group of people to govern themselves?',
      'How might everyday people help win a war?',
    ],
  },

  weather: {
    title: 'Weather & Water Cycle', subject: 'Science', emoji: '☁️', topicWord: 'weather and the water cycle',
    vocab: [
      { word: 'evaporate', pos: 'v.', def: 'To change from liquid into a gas.', sentence: 'The Sun makes puddles evaporate.' },
      { word: 'condense', pos: 'v.', def: 'To change from gas back into liquid.', sentence: 'Water vapor condenses into clouds.' },
      { word: 'precipitation', pos: 'n.', def: 'Water that falls as rain, snow, or hail.', sentence: 'Rain is a kind of precipitation.' },
      { word: 'vapor', pos: 'n.', def: 'Water in the form of a gas.', sentence: 'Warm air holds more water vapor.' },
      { word: 'cycle', pos: 'n.', def: 'A series of events that repeats.', sentence: 'The water cycle goes round and round.' },
      { word: 'atmosphere', pos: 'n.', def: 'The layer of air around the Earth.', sentence: 'Clouds form in the atmosphere.' },
      { word: 'temperature', pos: 'n.', def: 'How hot or cold something is.', sentence: 'The temperature dropped at night.' },
      { word: 'humid', pos: 'adj.', def: 'Having a lot of moisture in the air.', sentence: 'Summer days can feel humid.' },
    ],
    facts: [
      'The water cycle moves water between the Earth and sky.',
      'The Sun\u2019s heat makes water evaporate into vapor.',
      'Water vapor condenses to form clouds.',
      'Precipitation falls as rain, snow, sleet, or hail.',
      'The same water has been cycling for millions of years.',
      'Weather is what the air is doing right now in one place.',
    ],
    questions: [
      { q: 'What gives the energy that drives the water cycle?', choices: ['The Moon', 'The Sun', 'The wind', 'The soil'], answer: 1 },
      { q: 'When water turns into a gas, it…', choices: ['Freezes', 'Evaporates', 'Condenses', 'Falls'], answer: 1 },
      { q: 'Clouds form when water vapor…', choices: ['Evaporates', 'Condenses', 'Disappears', 'Freezes solid'], answer: 1 },
      { q: 'Rain and snow are kinds of…', choices: ['Evaporation', 'Precipitation', 'Vapor', 'Wind'], answer: 1 },
      { q: 'Water in gas form is called water…', choices: ['Ice', 'Vapor', 'Liquid', 'Steam only'], answer: 1 },
      { q: 'The layer of air around Earth is the…', choices: ['Ocean', 'Atmosphere', 'Crust', 'Orbit'], answer: 1 },
      { q: 'A series of events that repeats is a…', choices: ['Line', 'Cycle', 'List', 'Storm'], answer: 1 },
      { q: 'Humid air contains a lot of…', choices: ['Dust', 'Moisture', 'Smoke', 'Sand'], answer: 1 },
    ],
    passage: [
      'Have you ever wondered where rain comes from, or where a puddle goes when it dries up? The answer is the water cycle \u2014 the never-ending journey water takes between the Earth and the sky.',
      'It all begins with the Sun. The Sun\u2019s heat warms water in oceans, lakes, and rivers until some of it evaporates, turning into an invisible gas called water vapor. The vapor rises high into the atmosphere, where the air is cooler.',
      'As the vapor cools, it condenses, changing back into tiny drops of liquid water. Billions of these drops gather together to form clouds. When the drops grow heavy enough, they fall back to Earth as precipitation \u2014 rain, snow, sleet, or hail.',
      'The water that falls flows into rivers and oceans, or soaks into the ground. Then the Sun warms it again, and the whole cycle starts over. The amazing thing is that the same water keeps cycling, so the rain in your yard may have once been part of a faraway sea.',
    ],
    words: ['RAIN', 'CLOUD', 'EVAPORATE', 'CONDENSE', 'VAPOR', 'SUN', 'SNOW', 'RIVER', 'OCEAN', 'CYCLE', 'STORM', 'HUMID'],
    bigIdeas: [
      'Water moves in a repeating cycle between Earth and sky.',
      'The Sun\u2019s heat powers evaporation.',
      'Condensation forms clouds; precipitation returns water to Earth.',
      'Earth\u2019s water is reused again and again.',
    ],
    activities: [
      'Make a water cycle in a sealed bag taped to a sunny window.',
      'Label a water cycle diagram with the four main steps.',
      'Keep a one-week weather journal with simple symbols.',
      'Boil-free demo: warm water + cold lid to watch condensation.',
    ],
    discussion: [
      'Where does a puddle go when it dries up?',
      'Why do clouds form high in the sky and not near the ground?',
      'How can the same water be used over and over for millions of years?',
    ],
  },

  art: {
    title: 'Color & Famous Art', subject: 'Art', emoji: '🎨', topicWord: 'color and art',
    vocab: [
      { word: 'primary', pos: 'adj.', def: 'The basic colors \u2014 red, yellow, blue \u2014 used to mix others.', sentence: 'Red is a primary color.' },
      { word: 'secondary', pos: 'adj.', def: 'A color made by mixing two primary colors.', sentence: 'Green is a secondary color.' },
      { word: 'portrait', pos: 'n.', def: 'A picture of a person.', sentence: 'She painted a portrait of her mother.' },
      { word: 'sculpture', pos: 'n.', def: 'Art you can walk around, made of solid material.', sentence: 'The marble sculpture stood in the hall.' },
      { word: 'texture', pos: 'n.', def: 'How a surface looks or feels.', sentence: 'The painting had a rough texture.' },
      { word: 'shade', pos: 'n.', def: 'A darker version of a color.', sentence: 'Navy is a shade of blue.' },
      { word: 'canvas', pos: 'n.', def: 'The cloth an artist paints on.', sentence: 'He stretched the canvas on a frame.' },
      { word: 'pattern', pos: 'n.', def: 'A design that repeats.', sentence: 'The quilt had a colorful pattern.' },
    ],
    facts: [
      'The three primary colors are red, yellow, and blue.',
      'Mixing two primaries makes a secondary color.',
      'A portrait is a work of art showing a person.',
      'A sculpture is art you can see from all sides.',
      'Warm colors are reds and yellows; cool colors are blues and greens.',
      'Artists use texture and pattern to make art interesting.',
    ],
    questions: [
      { q: 'Which is a primary color?', choices: ['Green', 'Blue', 'Orange', 'Purple'], answer: 1 },
      { q: 'Red + yellow makes…', choices: ['Green', 'Orange', 'Purple', 'Brown'], answer: 1 },
      { q: 'A picture of a person is a…', choices: ['Landscape', 'Portrait', 'Pattern', 'Sketch only'], answer: 1 },
      { q: 'Art you can walk around is a…', choices: ['Painting', 'Sculpture', 'Drawing', 'Photo'], answer: 1 },
      { q: 'Blue and green are…', choices: ['Warm colors', 'Cool colors', 'Primary only', 'Shades of red'], answer: 1 },
      { q: 'A darker version of a color is a…', choices: ['Tint', 'Shade', 'Line', 'Frame'], answer: 1 },
      { q: 'A design that repeats is a…', choices: ['Pattern', 'Portrait', 'Palette', 'Canvas'], answer: 0 },
      { q: 'Artists paint on a…', choices: ['Canvas', 'Cloud', 'Mirror', 'Window'], answer: 0 },
    ],
    passage: [
      'Step into an art museum and you enter a world made of color, shape, and imagination. Artists have been creating for thousands of years, and they use a few simple tools \u2014 like color \u2014 in endless ways.',
      'Color begins with three primary colors: red, yellow, and blue. These cannot be made by mixing other colors, but they can be combined to make new ones. Mix red and yellow and you get orange. Mix blue and yellow and you get green. These new colors are called secondary colors.',
      'Art comes in many forms. A painting on canvas might show a portrait of a person or a landscape of the countryside. A sculpture is different \u2014 it is solid, and you can walk all the way around it to see every side. Artists also play with texture and pattern to make their work fun to look at.',
      'When you visit a gallery, slow down and really look. Notice the colors the artist chose, the way the light falls, and how the work makes you feel. Every piece of art tells a story \u2014 and you get to decide what it says to you.',
    ],
    words: ['RED', 'BLUE', 'YELLOW', 'PORTRAIT', 'SCULPTURE', 'CANVAS', 'COLOR', 'PATTERN', 'PAINT', 'TEXTURE', 'BRUSH', 'GALLERY'],
    bigIdeas: [
      'Primary colors mix to create secondary colors.',
      'Art takes many forms: painting, portrait, sculpture, and more.',
      'Warm and cool colors create different feelings.',
      'Looking closely helps us understand and enjoy art.',
    ],
    activities: [
      'Mix primary paints to discover every secondary color.',
      'Make a self-portrait using only warm or only cool colors.',
      'Build a small sculpture from clay or recycled materials.',
      'Create a repeating pattern and color it in.',
    ],
    discussion: [
      'Why can\u2019t you mix other colors to make a primary color?',
      'How can colors change the mood of a picture?',
      'What is the difference between a painting and a sculpture?',
    ],
  },
};

/* topic matching: synonyms → KB key */
const TOPIC_ALIASES = {
  ocean_animals: ['ocean', 'sea', 'aquarium', 'marine', 'fish', 'whale', 'shark', 'coral', 'underwater'],
  solar_system: ['solar', 'space', 'planet', 'planets', 'astronomy', 'star', 'moon', 'galaxy', 'universe'],
  dinosaurs: ['dinosaur', 'fossil', 'prehistoric', 'jurassic', 'paleontolog', 'natural history'],
  plants: ['plant', 'photosynthesis', 'flower', 'botan', 'garden', 'seed', 'tree', 'leaf'],
  zoo_animals: ['zoo', 'animal', 'habitat', 'mammal', 'wildlife', 'safari'],
  american_revolution: ['revolution', 'colon', 'independence', 'history', 'founding', '1776', 'patriot'],
  weather: ['weather', 'water cycle', 'rain', 'cloud', 'climate', 'storm'],
  art: ['art', 'color', 'paint', 'museum of art', 'gallery', 'sculpture'],
};

function matchTopic(topic) {
  const tl = (topic || '').toLowerCase();
  for (const [key, aliases] of Object.entries(TOPIC_ALIASES)) {
    if (aliases.some((a) => tl.includes(a))) return key;
  }
  return null;
}
function kbFor(topic) { const k = matchTopic(topic); return k ? KB[k] : null; }

/* ----------------------- Procedural math problems --------------------- */
function rnd(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function gcd(a, b) { return b ? gcd(b, a % b) : a; }

function mathProblems(topic, grade, count) {
  const tl = (topic || '').toLowerCase();
  const g = parseInt(String(grade).replace(/\D/g, '')) || 3;
  const out = [];
  const kindOf = () => {
    if (/fraction/.test(tl)) return 'fraction';
    if (/multipl|times|product/.test(tl)) return 'mult';
    if (/divi/.test(tl)) return 'div';
    if (/subtract|minus|difference/.test(tl)) return 'sub';
    if (/add|sum|plus/.test(tl)) return 'add';
    if (/place value/.test(tl)) return 'place';
    return ['add', 'sub', 'mult'][rnd(0, 2)];
  };
  for (let i = 0; i < count; i++) {
    const k = kindOf();
    if (k === 'fraction') {
      const d = rnd(2, Math.min(12, 4 + g));
      const a = rnd(1, d - 1), b = rnd(1, d - 1);
      const sum = a + b, q = `${a}/${d} + ${b}/${d}`;
      const div = gcd(sum, d);
      out.push({ q: q + ' =', answer: div > 1 && sum % div === 0 ? `${sum / div}/${d / div}` : `${sum}/${d}` });
    } else if (k === 'mult') {
      const hi = g <= 2 ? 5 : g <= 4 ? 12 : 20;
      const a = rnd(2, hi), b = rnd(2, hi);
      out.push({ q: `${a} × ${b} =`, answer: String(a * b) });
    } else if (k === 'div') {
      const b = rnd(2, g <= 3 ? 6 : 12), ans = rnd(2, 12);
      out.push({ q: `${b * ans} ÷ ${b} =`, answer: String(ans) });
    } else if (k === 'sub') {
      const hi = g <= 1 ? 20 : g <= 3 ? 100 : 1000;
      let a = rnd(Math.floor(hi / 2), hi), b = rnd(1, a);
      out.push({ q: `${a} − ${b} =`, answer: String(a - b) });
    } else if (k === 'place') {
      const n = rnd(g <= 2 ? 10 : 100, g <= 2 ? 99 : 9999);
      const places = ['ones', 'tens', 'hundreds', 'thousands'];
      const digits = String(n).split('').reverse();
      const idx = rnd(0, digits.length - 1);
      out.push({ q: `In ${n}, what digit is in the ${places[idx]} place?`, answer: digits[idx] });
    } else {
      const hi = g <= 1 ? 20 : g <= 3 ? 100 : 1000;
      const a = rnd(1, hi), b = rnd(1, hi);
      out.push({ q: `${a} + ${b} =`, answer: String(a + b) });
    }
  }
  return out;
}

/* ----------------------------- Generators ----------------------------- */
function makeWorksheet(meta) {
  const { topic, subject, grade, count = 10, hasKey = true, types = ['Mixed'] } = meta;
  const kb = kbFor(topic);
  let problems = [];
  if (subject === 'Math') {
    problems = mathProblems(topic, grade, count).map((p, i) => ({ ...p, kind: 'short' }));
  } else if (kb) {
    const pool = [];
    kb.questions.forEach((q) => pool.push({ q: q.q, answer: q.choices[q.answer], kind: 'short' }));
    kb.facts.forEach((f) => {
      const blanked = f.replace(/\b([A-Z][a-z]{4,}|photosynthesis|evaporate|condenses?|gravity|habitat|adaptation|independence)\b/, '__________');
      if (blanked !== f) pool.push({ q: blanked, answer: f, kind: 'fill' });
    });
    kb.vocab.forEach((v) => pool.push({ q: `Define: ${v.word}`, answer: v.def, kind: 'short' }));
    problems = shuffle(pool).slice(0, count);
  } else {
    for (let i = 0; i < count; i++) problems.push({
      q: `Write one fact you know about ${topic || 'this topic'}.`, answer: '(accept reasonable answers)', kind: 'short' });
  }
  return { kind: 'worksheet', instructions: subject === 'Math'
    ? 'Solve each problem. Show your work in the space provided.'
    : `Answer each question about ${kb ? kb.topicWord : topic}. Write in complete sentences.`,
    problems, hasKey };
}

function makeQuiz(meta) {
  const { topic, count = 8, types = ['Multiple choice'], includeTF = true } = meta;
  const kb = kbFor(topic);
  let questions = [];
  if (kb) {
    questions = shuffle(kb.questions).slice(0, count).map((q) => ({
      q: q.q, type: 'mcq', choices: q.choices, answer: q.answer }));
    if (includeTF && kb.facts.length) {
      // convert a couple facts into true/false
      const tfs = shuffle(kb.facts).slice(0, Math.min(2, Math.max(0, count - questions.length + 2)));
    }
  } else {
    for (let i = 0; i < count; i++) questions.push({
      q: `Which statement about ${topic || 'the topic'} is correct?`, type: 'mcq',
      choices: ['Answer A', 'Answer B', 'Answer C', 'Answer D'], answer: 0 });
  }
  return { kind: 'quiz', questions };
}

/* Real word-search generator */
function makeWordSearch(meta) {
  const { topic, size = 12, words: customWords, difficulty = 'Medium' } = meta;
  const kb = kbFor(topic);
  let words = (customWords && customWords.length ? customWords : (kb ? kb.words : ['LEARN', 'STUDY', 'READ', 'WRITE', 'THINK', 'GROW', 'EXPLORE', 'DISCOVER']))
    .map((w) => w.toUpperCase().replace(/[^A-Z]/g, '')).filter((w) => w.length >= 3 && w.length <= size);
  words = [...new Set(words)].slice(0, 12);
  const N = size;
  const grid = Array.from({ length: N }, () => Array(N).fill(''));
  const dirs = difficulty === 'Easy'
    ? [[0, 1], [1, 0]]
    : difficulty === 'Hard'
      ? [[0, 1], [1, 0], [1, 1], [-1, 1], [0, -1], [-1, 0], [-1, -1], [1, -1]]
      : [[0, 1], [1, 0], [1, 1], [-1, 1]];
  const placed = [];
  const tryPlace = (word) => {
    for (let attempt = 0; attempt < 120; attempt++) {
      const [dr, dc] = dirs[rnd(0, dirs.length - 1)];
      const r0 = rnd(0, N - 1), c0 = rnd(0, N - 1);
      const cells = [];
      let ok = true;
      for (let i = 0; i < word.length; i++) {
        const r = r0 + dr * i, c = c0 + dc * i;
        if (r < 0 || r >= N || c < 0 || c >= N) { ok = false; break; }
        const cur = grid[r][c];
        if (cur && cur !== word[i]) { ok = false; break; }
        cells.push([r, c]);
      }
      if (ok) { cells.forEach(([r, c], i) => grid[r][c] = word[i]); placed.push({ word, cells }); return true; }
    }
    return false;
  };
  const usedWords = [];
  words.forEach((w) => { if (tryPlace(w)) usedWords.push(w); });
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!grid[r][c]) grid[r][c] = A[rnd(0, 25)];
  return { kind: 'wordsearch', grid, words: usedWords, size: N, placed };
}

function makeVocab(meta) {
  const { topic, count = 8, customWords } = meta;
  const kb = kbFor(topic);
  let words = kb ? kb.vocab.slice(0, count) : null;
  if (!words) {
    const list = (customWords || (topic || 'study learn explore discover').split(/[\s,]+/)).filter(Boolean);
    words = list.slice(0, count).map((w) => ({ word: w.toLowerCase(), pos: 'n.',
      def: `A key term related to ${topic || 'this topic'}.`, sentence: `We learned about the ${w.toLowerCase()} today.` }));
  }
  return { kind: 'vocab', words };
}

function makeReading(meta) {
  const { topic, qCount = 5, lexile } = meta;
  const kb = kbFor(topic);
  let passage, questions, title;
  if (kb) {
    title = kb.title;
    passage = kb.passage;
    questions = shuffle(kb.questions).slice(0, qCount).map((q) => ({ q: q.q, answer: q.choices[q.answer] }));
  } else {
    title = topic || 'Reading Passage';
    passage = [
      `${topic || 'This topic'} is something many people find fascinating. There is a lot to discover when you take the time to look closely and ask good questions.`,
      `As you read, think about what you already know and what is new to you. Good readers pause to picture what is happening and to wonder why things work the way they do.`,
      `When you finish, try to explain the main idea in your own words. Then look back to find the small details that supported it.`,
    ];
    questions = [
      { q: `What is the main idea of this passage?`, answer: '(accept reasonable answers)' },
      { q: `Write one new thing you learned about ${topic || 'the topic'}.`, answer: '(answers will vary)' },
    ].slice(0, qCount);
  }
  return { kind: 'reading', title, passage, questions, lexile: lexile || (kb ? '600L–750L' : '—') };
}

function makeUnitStudy(place) {
  const kb = KB[place.topicKey] || KB.ocean_animals;
  return {
    kind: 'unitstudy',
    place: place.name,
    overview: `A hands-on unit study built around your visit to ${place.name}. Use it before, during, and after your trip to turn a fun day into deep, lasting learning across science, reading, writing, and math.`,
    subject: kb.subject,
    topicTitle: kb.title,
    bigIdeas: kb.bigIdeas,
    vocab: kb.vocab.slice(0, 6),
    beforeVisit: [
      `Read the reading passage on ${kb.topicWord} together and discuss the vocabulary words.`,
      `Have each learner write down two questions they hope to answer at ${place.name}.`,
    ],
    duringVisit: [
      'Find and sketch three things connected to the vocabulary words.',
      'Use the scavenger checklist below and check items off as you spot them.',
      'Ask a guide or staff member one of your prepared questions.',
    ],
    afterVisit: [
      'Complete the worksheet and quiz to review what you learned.',
      'Write a short journal entry: "The most surprising thing I learned was…"',
      'Pick one big idea and explain it to a family member.',
    ],
    activities: kb.activities,
    discussion: kb.discussion,
    scavenger: kb.words.slice(0, 6).map((w) => w[0] + w.slice(1).toLowerCase()),
  };
}

function shuffle(arr) { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = rnd(0, i);[a[i], a[j]] = [a[j], a[i]]; } return a; }

/* Dispatch + title */
function generate(type, meta) {
  switch (type) {
    case 'worksheet': return makeWorksheet(meta);
    case 'quiz': return makeQuiz(meta);
    case 'wordsearch': return makeWordSearch(meta);
    case 'vocab': return makeVocab(meta);
    case 'reading': return makeReading(meta);
    default: return makeWorksheet(meta);
  }
}

Object.assign(window, {
  KB, kbFor, matchTopic, generate, makeWorksheet, makeQuiz, makeWordSearch,
  makeVocab, makeReading, makeUnitStudy, mathProblems, shuffle, rnd,
});
