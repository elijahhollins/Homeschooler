/* ===================================================================== *
 *  places.jsx — Place Explorer data + seed library. Exports to window.
 * ===================================================================== */

const PLACE_TYPES = {
  Aquarium: { icon: 'reading', color: '#2b8a8a', soft: '#dff0f0' },
  Zoo: { icon: 'leaf', color: '#2f8a63', soft: '#e2f1ea' },
  'Science Museum': { icon: 'flask', color: '#3863a8', soft: '#e8eff8' },
  'Natural History': { icon: 'flag', color: '#c0762e', soft: '#f6ecd8' },
  'Art Museum': { icon: 'palette', color: '#a8538f', soft: '#f5e6f0' },
  'Botanical Garden': { icon: 'leaf', color: '#5a8a3a', soft: '#e8f1de' },
  Planetarium: { icon: 'globe', color: '#4a4a9a', soft: '#e7e7f5' },
  "Children's Museum": { icon: 'spark', color: '#c08a2e', soft: '#f6ecd8' },
  'Historic Site': { icon: 'flag', color: '#b05050', soft: '#f6e3e0' },
  'State Park': { icon: 'leaf', color: '#3a7a4a', soft: '#e2f0e4' },
};

/* default "near me" city + curated nearby places */
const HOME_CITY = 'Austin, TX';

const PLACES = [
  {
    id: 'p_aqua', name: 'Bayfront Aquarium', type: 'Aquarium', city: 'Austin, TX',
    distance: 3.2, rating: 4.7, reviews: 2140, topicKey: 'ocean_animals',
    hours: 'Open today · 9:00 AM – 6:00 PM', address: '120 Harbor Walk, Austin, TX',
    admission: '$24 adult · $16 child · under 3 free',
    blurb: 'Walk through a 40-ft glass tunnel surrounded by sharks and rays, touch tide-pool creatures, and watch the daily sea-otter feeding.',
    highlights: ['Shark tunnel', 'Touch tide pool', 'Sea otter feeding 11 AM & 3 PM', 'Jellyfish gallery'],
    deals: [
      { title: 'Homeschool Days', detail: 'Every 2nd Tuesday — $9 admission for registered homeschool families.', tag: 'Discount', icon: 'ticket', when: 'Monthly' },
      { title: 'Family Membership', detail: 'Unlimited visits + 10% gift-shop discount. Pays off in ~2 visits.', tag: 'Membership', icon: 'star', when: 'Annual' },
      { title: 'EBT / SNAP rate', detail: '$3 admission with a valid EBT card (up to 4 people).', tag: 'Access', icon: 'heart', when: 'Always' },
    ],
    resources: [
      { title: 'Marine Biology Co-op', detail: 'Local homeschool co-op meets here monthly for guided labs.', icon: 'users', meta: '24 families' },
      { title: 'Library Museum Pass', detail: 'Reserve a free family pass through the Austin Public Library.', icon: 'book', meta: 'Free' },
      { title: 'Junior Naturalist Program', detail: 'Drop-in badge program for ages 6–12, included with admission.', icon: 'flag', meta: 'Ages 6–12' },
    ],
  },
  {
    id: 'p_zoo', name: 'Hill Country Zoo & Safari', type: 'Zoo', city: 'Austin, TX',
    distance: 8.6, rating: 4.6, reviews: 3890, topicKey: 'zoo_animals',
    hours: 'Open today · 9:00 AM – 5:00 PM', address: '4500 Safari Rd, Austin, TX',
    admission: '$19 adult · $13 child · under 2 free',
    blurb: 'Home to lions, giraffes, and a walk-through lemur forest. The drive-through safari loop lets you feed zebras right from your car.',
    highlights: ['Giraffe feeding deck', 'Drive-through safari', 'Lemur forest', 'Big cat habitat'],
    deals: [
      { title: 'Homeschool Adventure Days', detail: 'First Friday each month — buy one, get one free admission.', tag: 'Discount', icon: 'ticket', when: 'Monthly' },
      { title: 'Zoo Membership', detail: 'Free parking + reciprocal entry at 150 zoos nationwide.', tag: 'Membership', icon: 'star', when: 'Annual' },
    ],
    resources: [
      { title: 'Homeschool Zoo Classes', detail: '6-week animal science series, registration required.', icon: 'users', meta: 'Ages 5–11' },
      { title: 'Scout Badge Days', detail: 'Earn an animal-science badge with a ranger-led tour.', icon: 'flag', meta: 'Sat AM' },
      { title: 'Library Pass', detail: 'Discounted family entry via the library partnership.', icon: 'book', meta: '$5' },
    ],
  },
  {
    id: 'p_sci', name: 'Thinkery Science Center', type: 'Science Museum', city: 'Austin, TX',
    distance: 5.1, rating: 4.8, reviews: 5210, topicKey: 'solar_system',
    hours: 'Open today · 10:00 AM – 5:00 PM', address: '88 Innovation Blvd, Austin, TX',
    admission: '$18 general · under 1 free',
    blurb: 'Three floors of hands-on exhibits: build a rocket, command a planet rover, and stand inside a tornado. The planetarium runs hourly shows.',
    highlights: ['Planetarium dome', 'Rocket build lab', 'Gravity well', 'Maker space'],
    deals: [
      { title: 'Homeschool Wednesdays', detail: 'Half-price admission every Wednesday for homeschoolers.', tag: 'Discount', icon: 'ticket', when: 'Weekly' },
      { title: 'Reciprocal Membership', detail: 'Free entry at 300+ ASTC science centers worldwide.', tag: 'Membership', icon: 'star', when: 'Annual' },
      { title: 'Free First Sunday', detail: 'Free general admission on the first Sunday of each month.', tag: 'Access', icon: 'heart', when: 'Monthly' },
    ],
    resources: [
      { title: 'Homeschool STEM Lab', detail: 'Weekly drop-in engineering challenges for ages 7–13.', icon: 'flask', meta: 'Wed 1 PM' },
      { title: 'Astronomy Club Night', detail: 'Telescope viewing with the local astronomy society.', icon: 'globe', meta: 'Monthly' },
      { title: 'Library Museum Pass', detail: 'Free family pass, reservable online.', icon: 'book', meta: 'Free' },
    ],
  },
  {
    id: 'p_nat', name: 'Lone Star Natural History Museum', type: 'Natural History', city: 'Austin, TX',
    distance: 6.7, rating: 4.7, reviews: 2980, topicKey: 'dinosaurs',
    hours: 'Open today · 9:00 AM – 5:00 PM', address: '210 Fossil Way, Austin, TX',
    admission: '$16 adult · $11 child',
    blurb: 'Stand beneath a full T. rex skeleton, dig for real fossils in the paleo lab, and explore the cave of glowing minerals.',
    highlights: ['T. rex skeleton hall', 'Fossil dig lab', 'Mineral cave', 'Texas wildlife dioramas'],
    deals: [
      { title: 'Homeschool Fossil Days', detail: '3rd Thursday — $7 admission + free dig-lab session.', tag: 'Discount', icon: 'ticket', when: 'Monthly' },
      { title: 'Curiosity Membership', detail: 'Unlimited visits + member-only fossil workshops.', tag: 'Membership', icon: 'star', when: 'Annual' },
    ],
    resources: [
      { title: 'Paleontology Co-op', detail: 'Hands-on dig sessions led by a museum educator.', icon: 'users', meta: '18 families' },
      { title: 'Homeschool Field Trip Kit', detail: 'Free downloadable guide + chaperone rates for groups of 8+.', icon: 'book', meta: 'Group rate' },
      { title: 'Junior Paleontologist Badge', detail: 'Complete 5 lab stations to earn a badge.', icon: 'flag', meta: 'Ages 6–12' },
    ],
  },
  {
    id: 'p_art', name: 'Riverside Art Museum', type: 'Art Museum', city: 'Austin, TX',
    distance: 4.4, rating: 4.5, reviews: 1760, topicKey: 'art',
    hours: 'Open today · 11:00 AM – 6:00 PM', address: '7 Gallery Row, Austin, TX',
    admission: '$14 adult · children free',
    blurb: 'A bright, family-friendly collection spanning portraits, sculpture, and a hands-on color studio where kids mix their own paint.',
    highlights: ['Color mixing studio', 'Sculpture garden', 'Portrait gallery', 'Family art carts'],
    deals: [
      { title: 'Free Family Sundays', detail: 'Free admission + guided kids tour every Sunday.', tag: 'Access', icon: 'heart', when: 'Weekly' },
      { title: 'Studio Membership', detail: 'Free studio classes and early exhibit access.', tag: 'Membership', icon: 'star', when: 'Annual' },
    ],
    resources: [
      { title: 'Homeschool Art Workshop', detail: 'Monthly themed studio session, materials included.', icon: 'palette', meta: 'Ages 5–14' },
      { title: 'Sketch in the Galleries', detail: 'Free sketchbooks and pencils for young artists.', icon: 'edit', meta: 'Free' },
      { title: 'Library Culture Pass', detail: 'Reserve free entry through the public library.', icon: 'book', meta: 'Free' },
    ],
  },
  {
    id: 'p_bot', name: 'Wildflower Botanical Gardens', type: 'Botanical Garden', city: 'Austin, TX',
    distance: 9.3, rating: 4.8, reviews: 2410, topicKey: 'plants',
    hours: 'Open today · 9:00 AM – 7:00 PM', address: '900 Meadow Ln, Austin, TX',
    admission: '$12 adult · $6 child',
    blurb: 'Themed gardens, a butterfly house, and a children\u2019s edible garden where kids can plant seeds and taste fresh herbs.',
    highlights: ['Butterfly house', 'Children\u2019s edible garden', 'Pollinator trail', 'Greenhouse'],
    deals: [
      { title: 'Homeschool Garden Days', detail: '2nd Monday — kids free with a paying adult.', tag: 'Discount', icon: 'ticket', when: 'Monthly' },
      { title: 'Garden Membership', detail: 'Unlimited visits + seed library access.', tag: 'Membership', icon: 'star', when: 'Annual' },
    ],
    resources: [
      { title: 'Nature Study Co-op', detail: 'Seasonal botany walks for homeschool groups.', icon: 'leaf', meta: 'Biweekly' },
      { title: 'Seed-to-Table Program', detail: 'Plant, grow, and harvest across a 6-week series.', icon: 'users', meta: 'Ages 6–12' },
      { title: 'Library Garden Pass', detail: 'Free family entry via library partnership.', icon: 'book', meta: 'Free' },
    ],
  },
];

/* Seed library — pre-saved materials so Library + Home feel lived-in.
   content is generated lazily by the app from these specs. */
const LIBRARY_SEED = [
  { id: 'seed1', type: 'worksheet', title: 'Fractions: Adding Like Denominators', subject: 'Math', grade: 'Grade 4', topic: 'fractions', meta: { topic: 'fractions', subject: 'Math', grade: 'Grade 4', count: 12, hasKey: true }, daysAgo: 1 },
  { id: 'seed2', type: 'quiz', title: 'The Water Cycle', subject: 'Science', grade: 'Grade 3', topic: 'water cycle', meta: { topic: 'water cycle', subject: 'Science', grade: 'Grade 3', count: 8 }, daysAgo: 2 },
  { id: 'seed3', type: 'wordsearch', title: 'Ocean Animals', subject: 'Science', grade: 'K–2', topic: 'ocean animals', meta: { topic: 'ocean animals', size: 12, difficulty: 'Easy' }, daysAgo: 4 },
  { id: 'seed4', type: 'reading', title: 'The Solar System', subject: 'Science', grade: 'Grade 5', topic: 'solar system', meta: { topic: 'solar system', qCount: 5 }, daysAgo: 6 },
  { id: 'seed5', type: 'vocab', title: 'Dinosaurs & Fossils', subject: 'Science', grade: 'Grade 3', topic: 'dinosaurs', meta: { topic: 'dinosaurs', count: 8 }, daysAgo: 9 },
];

const SHARED_SEED = [
  { id: 'sh1', type: 'unitstudy', title: 'Aquarium Unit Study', subject: 'Science', grade: 'K–5', topic: 'ocean animals', sharedBy: 'Priya N.', placeId: 'p_aqua', daysAgo: 3 },
  { id: 'sh2', type: 'worksheet', title: 'Multiplication Drills 0–12', subject: 'Math', grade: 'Grade 3', topic: 'multiplication', meta: { topic: 'multiplication', subject: 'Math', grade: 'Grade 3', count: 20, hasKey: true }, sharedBy: 'Marcus T.', daysAgo: 5 },
  { id: 'sh3', type: 'reading', title: 'The American Revolution', subject: 'Social Studies', grade: 'Grade 5', topic: 'american revolution', meta: { topic: 'american revolution', qCount: 6 }, sharedBy: 'Lena W.', daysAgo: 8 },
  { id: 'sh4', type: 'quiz', title: 'Animals & Habitats', subject: 'Science', grade: 'Grade 2', topic: 'animals habitats', meta: { topic: 'animals habitats', count: 8 }, sharedBy: 'Priya N.', daysAgo: 11 },
];

const CO_PARENTS = [
  { name: 'Priya N.', initials: 'PN', color: '#2f8a63' },
  { name: 'Marcus T.', initials: 'MT', color: '#3863a8' },
  { name: 'Lena W.', initials: 'LW', color: '#a8538f' },
  { name: 'Dana K.', initials: 'DK', color: '#c0762e' },
];

function placeById(id) { return PLACES.find((p) => p.id === id); }

Object.assign(window, { PLACE_TYPES, HOME_CITY, PLACES, LIBRARY_SEED, SHARED_SEED, CO_PARENTS, placeById });
