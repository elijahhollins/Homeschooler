/* ===================================================================== *
 *  shell.jsx — App shell (sidebar + topbar, responsive) + Home screen
 * ===================================================================== */

const NAV = [
  { group: 'Make', items: [
    { id: 'worksheet', icon: 'worksheet', label: 'Worksheets', view: { name: 'gen', type: 'worksheet' } },
    { id: 'quiz', icon: 'quiz', label: 'Quizzes', view: { name: 'gen', type: 'quiz' } },
    { id: 'wordsearch', icon: 'wordsearch', label: 'Word Search', view: { name: 'gen', type: 'wordsearch' } },
    { id: 'vocab', icon: 'vocab', label: 'Vocabulary', view: { name: 'gen', type: 'vocab' } },
    { id: 'reading', icon: 'reading', label: 'Reading Passages', view: { name: 'gen', type: 'reading' } },
  ] },
  { group: 'Discover', items: [
    { id: 'place', icon: 'place', label: 'Place Explorer', view: { name: 'places' } },
  ] },
  { group: 'Library', items: [
    { id: 'library', icon: 'library', label: 'My Library', view: { name: 'library' } },
    { id: 'shared', icon: 'share', label: 'Shared with me', view: { name: 'shared' } },
  ] },
];

function Sidebar({ nav, go, onClose, compact }) {
  const t = useT();
  const activeId = nav.name === 'gen' ? nav.type
    : nav.name === 'places' || nav.name === 'place' ? 'place'
    : nav.name === 'library' ? 'library'
    : nav.name === 'shared' ? 'shared' : nav.name === 'home' ? 'home' : null;
  return (
    <aside style={{ width: 236, flex: '0 0 236px', background: t.surface, borderRight: `1px solid ${t.border}`,
      padding: '20px 14px', display: 'flex', flexDirection: 'column', gap: 18, height: '100%', overflow: 'auto' }} className="hsk-scroll">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 6px' }}>
        <div onClick={() => go({ name: 'home' })} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
          <div style={{ width: 30, height: 30, borderRadius: t.badgeRadius - 1, background: t.accent, color: t.accentText,
            display: 'grid', placeItems: 'center', fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 16 }}>H</div>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 16.5, letterSpacing: t.headingLetter, color: t.text }}>HomeschoolKit</div>
        </div>
        {onClose && <IconButton name="close" size="sm" onClick={onClose} />}
      </div>

      <Button icon="spark" full onClick={() => go({ name: 'gen', type: 'worksheet' })}>Create new</Button>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <NavRow t={t} icon="home" label="Home" on={activeId === 'home'} onClick={() => go({ name: 'home' })} solo />
        {NAV.map((grp) => (
          <div key={grp.group} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.07em', color: t.textFaint,
              padding: '0 8px 6px', textTransform: 'uppercase' }}>{grp.group}</div>
            {grp.items.map((it) => (
              <NavRow key={it.id} t={t} icon={it.icon} label={it.label} on={activeId === it.id} onClick={() => go(it.view)} />
            ))}
          </div>
        ))}
      </nav>

      <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 10, padding: '12px 6px 2px', borderTop: `1px solid ${t.border}` }}>
        <div style={{ width: 30, height: 30, borderRadius: '50%', background: t.accentSoft, color: t.accentDeep,
          display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12 }}>DC</div>
        <div style={{ lineHeight: 1.25, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 13, color: t.text, whiteSpace: 'nowrap' }}>Desiree Carter</div>
          <div style={{ fontSize: 11.5, color: t.textMuted }}>3 learners</div>
        </div>
      </div>
    </aside>
  );
}

function NavRow({ t, icon, label, on, onClick, solo }) {
  const [h, setH] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 8px', borderRadius: t.radiusSm, cursor: 'pointer',
        background: on ? t.accentSoft : h ? t.surfaceAlt : 'transparent', color: on ? t.accentDeep : t.text,
        fontWeight: on ? 600 : 500, fontSize: 13.5, transition: 'background .12s', marginBottom: solo ? 2 : 0 }}>
      <Icon name={icon} size={17} stroke={on ? t.accent : t.textMuted} />{label}
    </div>
  );
}

function TopBar({ onMenu, go, onSearch, q, setQ }) {
  const t = useT();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 4px' }}>
      <button onClick={onMenu} className="hsk-only-mobile" style={{ display: 'none', width: 38, height: 38,
        placeItems: 'center', border: `1px solid ${t.border}`, borderRadius: t.radiusSm, background: t.surface, cursor: 'pointer', color: t.text }}>
        <Icon name="menu" size={20} />
      </button>
      <form onSubmit={(e) => { e.preventDefault(); onSearch && onSearch(q); }} style={{ flex: 1, maxWidth: 460 }}>
        <TextInput value={q} onChange={setQ} placeholder="Search your materials & places…" icon="search" />
      </form>
      <div style={{ flex: 1 }} />
      <Button variant="outline" size="md" icon="place" onClick={() => go({ name: 'places' })} style={{ }}>
        <span className="hsk-hide-sm">Place Explorer</span>
      </Button>
    </div>
  );
}

/* ------------------------------- Home -------------------------------- */
function Home({ go, library }) {
  const t = useT();
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const gens = [
    { type: 'worksheet', desc: 'Practice sets for any topic & level', meta: 'Math · ELA · Science' },
    { type: 'quiz', desc: 'Auto-graded checks with answer keys', meta: 'MCQ · Short answer' },
    { type: 'wordsearch', desc: 'Themed puzzles from your word list', meta: 'Printable' },
    { type: 'vocab', desc: 'Definitions, sentences & flashcards', meta: 'Builder' },
    { type: 'reading', desc: 'Leveled passages with questions', meta: 'Lexile-aware' },
  ];
  const recents = library.slice(0, 3);
  const PLURAL = { worksheet: 'Worksheets', quiz: 'Quizzes', wordsearch: 'Word Searches', vocab: 'Vocabulary Builder', reading: 'Reading Passages' };
  return (
    <div className="hsk-rise" style={{ maxWidth: 1080, margin: '0 auto' }}>
      <div style={{ marginBottom: 26 }}>
        <h1 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 30, letterSpacing: t.headingLetter, color: t.text }}>{greet}, Desiree</h1>
        <p style={{ margin: '6px 0 0', color: t.textMuted, fontSize: 15 }}>Let's make something worth learning today.</p>
      </div>

      <SectionTitle sub="AI drafts it in seconds — you edit & print">Create</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14 }}>
        {gens.map((g) => {
          const m = GEN_META[g.type];
          return (
            <Card key={g.type} hover pad={16} onClick={() => go({ name: 'gen', type: g.type })}
              style={{ display: 'flex', flexDirection: 'column', gap: 11, minHeight: 118 }}>
              <GenBadge type={g.type} />
              <div>
                <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 15.5, letterSpacing: t.headingLetter, color: t.text }}>{PLURAL[g.type]}</div>
                <div style={{ color: t.textMuted, fontSize: 12.5, marginTop: 3, lineHeight: 1.35 }}>{g.desc}</div>
              </div>
              <div style={{ marginTop: 'auto', fontFamily: t.fontMono, fontSize: 10.5, color: t.textFaint }}>{g.meta}</div>
            </Card>
          );
        })}
      </div>

      {/* Place Explorer banner */}
      <div onClick={() => go({ name: 'places' })} style={{ marginTop: 18, padding: 20, display: 'flex', alignItems: 'center', gap: 18,
        background: `linear-gradient(100deg, ${t.accentSoft}, ${t.surface})`, border: `1px solid ${t.accentLine}`,
        borderRadius: t.radius, cursor: 'pointer', flexWrap: 'wrap' }}>
        <div style={{ width: 50, height: 50, flex: '0 0 50px', borderRadius: t.badgeRadius, background: t.accent, color: '#fff', display: 'grid', placeItems: 'center' }}>
          <Icon name="place" size={26} />
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, letterSpacing: t.headingLetter, color: t.text }}>Going somewhere? Turn the trip into a lesson.</div>
          <div style={{ color: t.textMuted, fontSize: 13.5, marginTop: 3 }}>Find aquariums, zoos & museums near you — get a ready unit study plus local homeschool deals.</div>
          <div style={{ display: 'flex', gap: 7, marginTop: 12, flexWrap: 'wrap' }}>
            {['Aquariums', 'Zoos', 'Science Museums', 'Botanical Gardens'].map((c) => (
              <span key={c} style={{ background: t.surface, border: `1px solid ${t.accentLine}`, borderRadius: 999, padding: '5px 11px', fontSize: 12, color: t.text, whiteSpace: 'nowrap' }}>{c}</span>
            ))}
          </div>
        </div>
        <Button icon="search" onClick={() => go({ name: 'places' })}>Explore places</Button>
      </div>

      {/* Recent */}
      <div style={{ marginTop: 26 }}>
        <SectionTitle action={<span onClick={() => go({ name: 'library' })} style={{ color: t.accent, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>View all →</span>}>Recent in your library</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 14 }}>
          {recents.map((r) => <MaterialCard key={r.id} m={r} go={go} />)}
        </div>
      </div>
    </div>
  );
}

/* Reusable material card (used by Home + Library) */
function MaterialCard({ m, go, onShare }) {
  const t = useT();
  const meta = GEN_META[m.type] || GEN_META.worksheet;
  const col = subjectColor(m.subject);
  return (
    <Card hover pad={0} onClick={() => go({ name: 'material', id: m.id })} style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 96, background: `repeating-linear-gradient(135deg, ${t.surfaceAlt}, ${t.surfaceAlt} 9px, ${t.surfaceSunken} 9px, ${t.surfaceSunken} 18px)`,
        borderBottom: `1px solid ${t.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <div style={{ opacity: 0.55 }}><Icon name={meta.icon} size={34} stroke={col.c} /></div>
        <span style={{ position: 'absolute', top: 10, left: 10 }}><Badge soft={col.soft} color={col.c} icon={meta.icon}>{meta.label}</Badge></span>
      </div>
      <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.3, color: t.text }}>{m.title}</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto' }}>
          <span style={{ color: t.textMuted, fontSize: 12 }}>{m.grade} · {m.subject}</span>
          {m.sharedBy
            ? <Badge soft={t.surfaceAlt}><Icon name="users" size={11} /> {m.sharedBy}</Badge>
            : onShare && <IconButton name="share" size="sm" onClick={(e) => { e.stopPropagation(); onShare(m); }} />}
        </div>
      </div>
    </Card>
  );
}

Object.assign(window, { NAV, Sidebar, NavRow, TopBar, Home, MaterialCard });
