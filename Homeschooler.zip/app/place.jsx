/* ===================================================================== *
 *  place.jsx — Place Explorer, place detail, unit study + local deals
 * ===================================================================== */

function PlaceExplorer({ go, toast }) {
  const t = useT();
  const [q, setQ] = useState('');
  const [located, setLocated] = useState(false);
  const [filter, setFilter] = useState('All');
  const [focus, setFocus] = useState(false);
  const types = ['All', ...Object.keys(PLACE_TYPES)].filter((ty) => ty === 'All' || PLACES.some((p) => p.type === ty));

  const matches = PLACES.filter((p) => {
    const okType = filter === 'All' || p.type === filter;
    const okQ = !q || (p.name + ' ' + p.type + ' ' + p.city).toLowerCase().includes(q.toLowerCase());
    return okType && okQ;
  }).sort((a, b) => a.distance - b.distance);

  const dropdown = q && focus ? PLACES.filter((p) => (p.name + ' ' + p.type).toLowerCase().includes(q.toLowerCase())).slice(0, 5) : [];

  return (
    <div className="hsk-rise" style={{ maxWidth: 1080, margin: '0 auto' }}>
      <PageHead t={t} title="Place Explorer" sub="Find a place you're visiting — get a ready unit study plus local homeschool deals." />

      {/* Search hero */}
      <div style={{ background: `linear-gradient(115deg, ${t.accentSoft}, ${t.surface})`, border: `1px solid ${t.accentLine}`,
        borderRadius: t.radiusLg, padding: 22 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'stretch' }}>
          <div style={{ flex: '1 1 320px', position: 'relative' }}>
            <TextInput value={q} onChange={setQ} placeholder="Search aquariums, zoos, museums, parks…" icon="search"
              style={{ background: t.surface, padding: '3px 13px' }} />
            <input style={{ display: 'none' }} onFocus={() => setFocus(true)} />
            <div onMouseDown={(e) => e.preventDefault()}>
              {dropdown.length > 0 && (
                <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 6, background: t.surface,
                  border: `1px solid ${t.border}`, borderRadius: t.radius, boxShadow: t.shadowLg, zIndex: 20, overflow: 'hidden' }}>
                  {dropdown.map((p) => {
                    const ty = PLACE_TYPES[p.type];
                    return (
                      <div key={p.id} onClick={() => { setQ(''); go({ name: 'place', id: p.id }); }}
                        style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '10px 13px', cursor: 'pointer' }}
                        onMouseEnter={(e) => e.currentTarget.style.background = t.surfaceAlt}
                        onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                        <div style={{ width: 30, height: 30, borderRadius: 8, background: ty.soft, color: ty.color, display: 'grid', placeItems: 'center', flex: '0 0 30px' }}><Icon name={ty.icon} size={16} stroke={ty.color} /></div>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: 13.5, fontWeight: 600, color: t.text }}>{p.name}</div>
                          <div style={{ fontSize: 12, color: t.textMuted }}>{p.type} · {p.distance} mi</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
          <Button size="lg" variant={located ? 'soft' : 'primary'} icon="locate"
            onClick={() => { setLocated(true); toast('Showing places near ' + HOME_CITY, 'pin'); }}>
            {located ? 'Near ' + HOME_CITY : 'Use my location'}
          </Button>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, color: t.textMuted, fontSize: 13 }}>
          <Icon name="pin" size={15} stroke={t.accent} />
          <span>{located ? <>Showing <b style={{ color: t.text }}>{matches.length}</b> places near <b style={{ color: t.text }}>{HOME_CITY}</b></> : 'Set your location or search to explore nearby places'}</span>
        </div>
      </div>

      {/* Type filters */}
      <div className="hsk-scroll" style={{ display: 'flex', gap: 8, margin: '20px 0 16px', overflowX: 'auto', paddingBottom: 4 }}>
        {types.map((ty) => (
          <ChipToggle key={ty} label={ty} icon={ty !== 'All' ? PLACE_TYPES[ty].icon : 'grid'} on={filter === ty} onClick={() => setFilter(ty)} />
        ))}
      </div>

      {/* Place grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
        {matches.map((p) => <PlaceCard key={p.id} place={p} go={go} />)}
      </div>
      {matches.length === 0 && <div style={{ textAlign: 'center', color: t.textMuted, padding: 50 }}>No places match “{q}”. Try another search.</div>}
    </div>
  );
}

function PlaceCard({ place, go }) {
  const t = useT();
  const ty = PLACE_TYPES[place.type];
  return (
    <Card hover pad={0} onClick={() => go({ name: 'place', id: place.id })} style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 130, position: 'relative', background: `repeating-linear-gradient(135deg, ${ty.soft}, ${ty.soft} 11px, ${t.surface} 11px, ${t.surface} 22px)`,
        display: 'grid', placeItems: 'center', borderBottom: `1px solid ${t.border}` }}>
        <div style={{ opacity: 0.5 }}><Icon name={ty.icon} size={40} stroke={ty.color} /></div>
        <span style={{ position: 'absolute', top: 10, left: 10 }}><Badge soft={ty.soft} color={ty.color} icon={ty.icon}>{place.type}</Badge></span>
        <span style={{ position: 'absolute', top: 10, right: 10 }}><Badge soft={t.surface} color={t.warn} icon="star">{place.rating}</Badge></span>
      </div>
      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 9, flex: 1 }}>
        <div>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 16, letterSpacing: t.headingLetter, color: t.text }}>{place.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: t.textMuted, fontSize: 12.5, marginTop: 4 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="pin" size={13} />{place.distance} mi</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="clock" size={13} />{place.hours.replace('Open today · ', '')}</span>
          </div>
        </div>
        <p style={{ margin: 0, color: t.textMuted, fontSize: 13, lineHeight: 1.45, flex: 1 }}>{place.blurb}</p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
          {place.deals.some((d) => d.tag === 'Discount' || d.tag === 'Access')
            ? <Badge soft={t.goodSoft} color={t.good} icon="ticket">Homeschool deal</Badge> : <span />}
          <span style={{ color: t.accent, fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>View <Icon name="chevR" size={14} /></span>
        </div>
      </div>
    </Card>
  );
}

/* ---------------------------- Place Detail ---------------------------- */
function PlaceDetail({ place, go, onSave, onShare, toast }) {
  const t = useT();
  const ty = PLACE_TYPES[place.type];
  const [unit, setUnit] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false);
  const unitRef = useRef(null);

  const genUnit = () => {
    setLoading(true); setUnit(null);
    setTimeout(() => {
      const content = makeUnitStudy(place);
      setUnit({ id: uid(), type: 'unitstudy', title: `${place.name} — Unit Study`, subject: content.subject,
        grade: 'K–5', topic: place.topicKey, content, createdAt: Date.now(), source: 'place', placeId: place.id });
      setLoading(false);
      setTimeout(() => unitRef.current && window.scrollTo({ top: unitRef.current.offsetTop - 20, behavior: 'smooth' }), 60);
    }, 950);
  };
  const quickGen = (gtype) => go({ name: 'gen', type: gtype, seed: { topic: KB[place.topicKey].topicWord, subject: KB[place.topicKey].subject, grade: 'Grade 3', auto: true } });

  return (
    <div className="hsk-rise" style={{ maxWidth: 1000, margin: '0 auto' }}>
      <button onClick={() => go({ name: 'places' })} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 'none',
        color: t.textMuted, cursor: 'pointer', fontFamily: t.fontBody, fontSize: 13, fontWeight: 600, padding: 0, marginBottom: 14 }}>
        <Icon name="arrowL" size={16} />Place Explorer
      </button>

      {/* Hero */}
      <div style={{ borderRadius: t.radiusLg, overflow: 'hidden', border: `1px solid ${t.border}`, boxShadow: t.shadowSm }}>
        <div style={{ height: 190, position: 'relative', background: `repeating-linear-gradient(135deg, ${ty.soft}, ${ty.soft} 13px, ${t.surface} 13px, ${t.surface} 26px)`, display: 'grid', placeItems: 'center' }}>
          <div style={{ opacity: 0.5 }}><Icon name={ty.icon} size={56} stroke={ty.color} /></div>
          <span style={{ position: 'absolute', bottom: 12, right: 12, fontFamily: t.fontMono, fontSize: 10.5, color: t.textFaint, background: t.surface, padding: '3px 8px', borderRadius: 6, border: `1px solid ${t.border}` }}>{place.name} — photo</span>
        </div>
        <div style={{ padding: 22, background: t.surface }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 14, flexWrap: 'wrap' }}>
            <div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <Badge soft={ty.soft} color={ty.color} icon={ty.icon}>{place.type}</Badge>
                <Badge soft={t.warnSoft} color={t.warn} icon="star">{place.rating} ({place.reviews.toLocaleString()})</Badge>
              </div>
              <h1 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 28, letterSpacing: t.headingLetter, color: t.text }}>{place.name}</h1>
              <p style={{ margin: '8px 0 0', color: t.textMuted, fontSize: 14.5, lineHeight: 1.55, maxWidth: 620 }}>{place.blurb}</p>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginTop: 18 }}>
            {[{ ic: 'pin', l: 'Address', v: place.address }, { ic: 'clock', l: 'Hours', v: place.hours.replace('Open today · ', '') + ' (today)' }, { ic: 'dollar', l: 'Admission', v: place.admission }].map((x) => (
              <div key={x.l} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: t.surfaceAlt, color: t.textMuted, display: 'grid', placeItems: 'center', flex: '0 0 32px' }}><Icon name={x.ic} size={16} /></div>
                <div><div style={{ fontSize: 11.5, color: t.textFaint, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{x.l}</div>
                  <div style={{ fontSize: 13, color: t.text, marginTop: 2 }}>{x.v}</div></div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 16 }}>
            {place.highlights.map((h) => <Badge key={h} soft={t.surfaceAlt} color={t.textMuted} icon="check">{h}</Badge>)}
          </div>
        </div>
      </div>

      {/* Generate unit study CTA */}
      <Card pad={20} style={{ marginTop: 18, background: `linear-gradient(110deg, ${t.accentSoft}, ${t.surface})`, border: `1px solid ${t.accentLine}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <div style={{ width: 48, height: 48, borderRadius: t.badgeRadius, background: t.accent, color: '#fff', display: 'grid', placeItems: 'center', flex: '0 0 48px' }}><Icon name="sparkles" size={24} /></div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, color: t.text }}>Build a unit study for this visit</div>
            <div style={{ color: t.textMuted, fontSize: 13.5, marginTop: 2 }}>A complete lesson on <b style={{ color: t.text }}>{KB[place.topicKey].title}</b> — big ideas, vocabulary, before/during/after activities & a scavenger hunt.</div>
          </div>
          <Button size="lg" icon="sparkles" onClick={genUnit}>{unit ? 'Regenerate' : 'Generate unit study'}</Button>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 16, alignItems: 'center' }}>
          <span style={{ fontSize: 12.5, color: t.textMuted, fontWeight: 600 }}>Quick add:</span>
          {[['worksheet', 'Worksheet'], ['quiz', 'Quiz'], ['wordsearch', 'Word search'], ['reading', 'Reading passage']].map(([gt, lb]) => (
            <button key={gt} onClick={() => quickGen(gt)} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, border: `1px solid ${t.border}`, background: t.surface,
              borderRadius: 999, padding: '6px 12px', cursor: 'pointer', fontSize: 12.5, fontWeight: 600, color: t.text, fontFamily: t.fontBody }}>
              <Icon name="plus" size={13} stroke={t.accent} />{lb}</button>
          ))}
        </div>
      </Card>

      {/* Unit study result */}
      <div ref={unitRef}>
        {loading && <Card pad={0} style={{ marginTop: 18 }}><GenLoader label={`Building your ${place.name} unit study…`} /></Card>}
        {unit && !loading && (
          <div className="hsk-rise" style={{ marginTop: 18 }}>
            <div className="hsk-no-print" style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, flexWrap: 'wrap',
              background: t.surface, border: `1px solid ${t.border}`, borderRadius: t.radius, padding: 10, boxShadow: t.shadowSm }}>
              <Badge soft={t.goodSoft} color={t.good} icon="sparkles">Unit study ready</Badge>
              <div style={{ flex: 1 }} />
              <Segmented size="sm" value={editing ? 'edit' : 'view'} onChange={(v) => setEditing(v === 'edit')} options={[{ value: 'view', label: 'View', icon: 'book' }, { value: 'edit', label: 'Edit', icon: 'edit' }]} />
              <IconButton name="print" title="Print" onClick={() => window.print()} />
              <Button size="sm" variant="outline" icon="share" onClick={() => onShare(unit)}>Share</Button>
              <Button size="sm" icon="save" onClick={() => onSave(unit)}>Save to library</Button>
            </div>
            <MaterialDoc material={unit} update={setUnit} editing={editing} />
          </div>
        )}
      </div>

      {/* Local deals & resources */}
      <div style={{ marginTop: 28 }}>
        <SectionTitle sub={`Near ${place.city}`}>Homeschool deals & resources nearby</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 16 }}>
          <Card pad={18}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <Icon name="ticket" size={18} stroke={t.good} /><span style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 15, color: t.text }}>Deals & discounts</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {place.deals.map((d, i) => (
                <div key={i} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 9, background: t.goodSoft, color: t.good, display: 'grid', placeItems: 'center', flex: '0 0 36px' }}><Icon name={d.icon} size={17} stroke={t.good} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 600, fontSize: 13.5, color: t.text }}>{d.title}</span>
                      <Badge soft={t.surfaceAlt} color={t.textMuted}>{d.when}</Badge>
                    </div>
                    <div style={{ fontSize: 12.5, color: t.textMuted, marginTop: 2, lineHeight: 1.4 }}>{d.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
          <Card pad={18}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <Icon name="users" size={18} stroke={t.accent} /><span style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 15, color: t.text }}>Co-ops & programs</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {place.resources.map((r, i) => (
                <div key={i} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 9, background: t.accentSoft, color: t.accent, display: 'grid', placeItems: 'center', flex: '0 0 36px' }}><Icon name={r.icon} size={17} stroke={t.accent} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 600, fontSize: 13.5, color: t.text }}>{r.title}</span>
                      <Badge soft={t.accentSoft} color={t.accentDeep}>{r.meta}</Badge>
                    </div>
                    <div style={{ fontSize: 12.5, color: t.textMuted, marginTop: 2, lineHeight: 1.4 }}>{r.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PlaceExplorer, PlaceCard, PlaceDetail });
