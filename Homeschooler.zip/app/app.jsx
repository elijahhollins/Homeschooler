/* ===================================================================== *
 *  app.jsx — Router, state, persistence, mount
 * ===================================================================== */

function hydrate(seed) {
  let m;
  if (seed.type === 'unitstudy') {
    const place = placeById(seed.placeId) || PLACES[0];
    const content = makeUnitStudy(place);
    m = { id: seed.id, type: 'unitstudy', title: seed.title, subject: content.subject, grade: seed.grade, topic: seed.topic, content, placeId: seed.placeId };
  } else {
    const built = buildMaterial(seed.type, seed.meta);
    m = { ...built, id: seed.id, title: seed.title, subject: seed.subject, grade: seed.grade };
  }
  m.createdAt = Date.now() - (seed.daysAgo || 0) * 86400000;
  m.source = seed.sharedBy ? 'shared' : 'generated';
  if (seed.sharedBy) m.sharedBy = seed.sharedBy;
  return m;
}

function App() {
  const t = BASE_THEME;
  const [view, setView] = useState(() => store.get('view', { name: 'home' }));
  const [library, setLibrary] = useState(() => {
    const saved = store.get('library.v2', null);
    if (saved) return saved;
    return LIBRARY_SEED.map(hydrate);
  });
  const [shared] = useState(() => SHARED_SEED.map(hydrate));
  const [toastVal, setToastVal] = useState(null);
  const [shareTarget, setShareTarget] = useState(null);
  const [drawer, setDrawer] = useState(false);
  const [topQ, setTopQ] = useState('');
  const toastTimer = useRef(null);
  const scrollRef = useRef(null);

  useEffect(() => { store.set('library.v2', library); }, [library]);
  useEffect(() => { store.set('view', view); }, [view]);

  const toast = useCallback((msg, icon) => {
    setToastVal({ msg, icon });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVal(null), 2400);
  }, []);

  const go = useCallback((v) => {
    setView(v); setDrawer(false);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
    window.scrollTo({ top: 0 });
  }, []);

  const saveMaterial = useCallback((m) => {
    setLibrary((lib) => {
      const exists = lib.some((x) => x.id === m.id);
      return exists ? lib.map((x) => x.id === m.id ? m : x) : [{ ...m, createdAt: Date.now() }, ...lib];
    });
    toast('Saved to your library', 'save');
  }, [toast]);

  const updateMaterial = useCallback((m, addNew) => {
    if (addNew) { setLibrary((lib) => [{ ...m, createdAt: Date.now() }, ...lib]); toast('Saved a copy to your library', 'save'); go({ name: 'material', id: m.id }); }
    else setLibrary((lib) => lib.map((x) => x.id === m.id ? m : x));
  }, [toast, go]);

  const deleteMaterial = useCallback((id) => { setLibrary((lib) => lib.filter((x) => x.id !== id)); toast('Deleted', 'trash'); }, [toast]);
  const openShare = useCallback((m) => setShareTarget(m), []);

  const findMaterial = (id) => library.find((x) => x.id === id) || shared.find((x) => x.id === id);

  let screen;
  if (view.name === 'home') screen = <Home go={go} library={library} />;
  else if (view.name === 'gen') screen = <GeneratorScreen key={'gen-' + view.type + (view.seed ? JSON.stringify(view.seed) : '')} type={view.type} go={go} onSave={saveMaterial} onShare={openShare} toast={toast} seed={view.seed} />;
  else if (view.name === 'places') screen = <PlaceExplorer go={go} toast={toast} />;
  else if (view.name === 'place') screen = <PlaceDetail place={placeById(view.id)} go={go} onSave={saveMaterial} onShare={openShare} toast={toast} />;
  else if (view.name === 'library') screen = <LibraryScreen library={library} go={go} onShare={openShare} onDelete={deleteMaterial} toast={toast} />;
  else if (view.name === 'shared') screen = <SharedScreen shared={shared} go={go} />;
  else if (view.name === 'material') {
    const m = findMaterial(view.id);
    screen = m ? <MaterialView material={m} go={go} onUpdate={updateMaterial} onShare={openShare} onDelete={deleteMaterial} fromShared={m.source === 'shared'} />
      : <div style={{ padding: 40, textAlign: 'center', color: t.textMuted }}>Material not found.</div>;
  } else screen = <Home go={go} library={library} />;

  return (
    <ThemeContext.Provider value={t}>
      <div style={{ display: 'flex', height: '100vh', background: t.bg, color: t.text, fontFamily: t.fontBody, overflow: 'hidden' }}>
        {drawer && <div className="hsk-scrim" onClick={() => setDrawer(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(20,30,45,0.4)', zIndex: 90 }} />}
        <div className={cx('hsk-sidebar-wrap', drawer && 'open')}>
          <Sidebar nav={view} go={go} onClose={drawer ? () => setDrawer(false) : null} />
        </div>
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <div style={{ padding: '16px 24px 12px', borderBottom: `1px solid ${t.border}`, background: t.surface, flex: '0 0 auto' }}>
            <TopBar onMenu={() => setDrawer(true)} go={go} q={topQ} setQ={setTopQ}
              onSearch={(query) => { if (query) { go({ name: 'library' }); } }} />
          </div>
          <div ref={scrollRef} className="hsk-scroll" style={{ flex: 1, overflow: 'auto', padding: '26px 24px 60px' }}>
            {screen}
          </div>
        </main>
      </div>
      <Toast toast={toastVal} />
      {shareTarget && <ShareModal material={shareTarget} onClose={() => setShareTarget(null)} toast={toast} />}
    </ThemeContext.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
