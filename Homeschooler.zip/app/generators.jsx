/* ===================================================================== *
 *  generators.jsx — Generator screens (form + result) for all 5 types
 * ===================================================================== */

const SUBJECTS = ['Math', 'Science', 'ELA', 'Social Studies', 'Art'];
const GRADES = ['Pre-K', 'Kindergarten', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8'];

const TOPIC_SUGGESTIONS = {
  Math: ['Adding fractions', 'Multiplication 0–12', 'Place value', 'Division facts', 'Subtraction with regrouping'],
  Science: ['Ocean animals', 'The solar system', 'Dinosaurs & fossils', 'Plants & photosynthesis', 'Weather & water cycle', 'Animals & habitats'],
  ELA: ['Synonyms & antonyms', 'Parts of speech', 'Main idea'],
  'Social Studies': ['The American Revolution', 'Map skills', 'Community helpers'],
  Art: ['Color & famous art', 'Primary colors'],
};

const GEN_INTRO = {
  worksheet: 'Generate a printable practice worksheet for any subject and level.',
  quiz: 'Generate an auto-graded quiz with an answer key.',
  wordsearch: 'Generate a printable word-search puzzle from any theme.',
  vocab: 'Build a vocabulary set with definitions, sentences & flashcards.',
  reading: 'Generate a leveled reading passage with comprehension questions.',
};

function titleCase(s) { return (s || '').replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase()); }

function buildMaterial(type, f) {
  const kb = kbFor(f.topic);
  const meta = { ...f };
  const content = generate(type, meta);
  let subject = f.subject || (kb && kb.subject) || 'Science';
  let title = f.topic ? titleCase(f.topic) : (kb ? kb.title : GEN_META[type].label);
  if (kb) title = kb.title;
  if (type === 'wordsearch' && !f.topic) title = 'Word Search';
  return { id: uid(), type, title, subject, grade: f.grade || 'All ages', topic: f.topic, meta, content, createdAt: Date.now(), source: 'generated' };
}

function GeneratorScreen({ type, go, onSave, onShare, toast, seed }) {
  const t = useT();
  const meta = GEN_META[type];
  const defaults = {
    worksheet: { subject: 'Math', topic: '', grade: 'Grade 4', count: 10, hasKey: true },
    quiz: { subject: 'Science', topic: '', grade: 'Grade 3', count: 8, difficulty: 'Medium', includeTF: true },
    wordsearch: { topic: '', size: 12, difficulty: 'Medium', customWords: '' },
    vocab: { subject: 'Science', topic: '', grade: 'Grade 3', count: 8 },
    reading: { subject: 'Science', topic: '', grade: 'Grade 4', qCount: 5 },
  }[type];
  const [form, setForm] = useState({ ...defaults, ...(seed || {}) });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const doGenerate = () => {
    setEditing(false); setLoading(true); setResult(null);
    const meta2 = { ...form };
    if (type === 'wordsearch' && form.customWords) meta2.words = form.customWords.split(/[\s,\n]+/).filter(Boolean);
    setTimeout(() => { setResult(buildMaterial(type, meta2)); setLoading(false); }, 850);
  };

  // auto-generate when seeded from a place
  useEffect(() => { if (seed && seed.auto) doGenerate(); /* eslint-disable-next-line */ }, []);

  const suggestions = TOPIC_SUGGESTIONS[form.subject] || TOPIC_SUGGESTIONS.Science;
  const canGen = type === 'wordsearch' ? true : form.topic.trim().length > 0;

  return (
    <div className="hsk-rise">
      <PageHead t={t} go={go} icon={meta.icon} type={type} title={`${meta.label} Generator`} sub={GEN_INTRO[type]} />
      <div style={{ display: 'flex', gap: 22, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* FORM */}
        <Card pad={20} style={{ width: 348, flex: '1 1 320px', maxWidth: 420, position: 'sticky', top: 0 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {type !== 'wordsearch' && (
              <Field label="Subject">
                <Select value={form.subject} onChange={(v) => set('subject', v)} options={SUBJECTS} />
              </Field>
            )}
            <Field label={type === 'wordsearch' ? 'Theme or topic' : 'Topic'} hint={type === 'wordsearch' ? 'We\u2019ll pull a themed word list automatically.' : undefined}>
              <TextInput value={form.topic} onChange={(v) => set('topic', v)}
                placeholder={type === 'wordsearch' ? 'e.g. Ocean animals' : 'e.g. Adding fractions, Ocean animals…'} icon="spark" />
            </Field>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginTop: -6 }}>
              {suggestions.slice(0, 4).map((s) => (
                <button key={s} onClick={() => set('topic', s)} style={{ border: `1px solid ${t.border}`, background: t.surface, color: t.textMuted,
                  borderRadius: 999, padding: '5px 10px', fontSize: 12, cursor: 'pointer', fontFamily: t.fontBody, fontWeight: 500 }}>{s}</button>
              ))}
            </div>

            {(type === 'worksheet' || type === 'quiz' || type === 'vocab' || type === 'reading') && (
              <Field label="Grade / level"><Select value={form.grade} onChange={(v) => set('grade', v)} options={GRADES} /></Field>
            )}

            {type === 'worksheet' && (<>
              <Field label="Number of problems"><Stepper value={form.count} onChange={(v) => set('count', v)} min={4} max={30} /></Field>
              <Field label="Options">
                <ChipToggle label="Include answer key" icon="check" on={form.hasKey} onClick={() => set('hasKey', !form.hasKey)} />
              </Field>
            </>)}

            {type === 'quiz' && (<>
              <Field label="Number of questions"><Stepper value={form.count} onChange={(v) => set('count', v)} min={4} max={20} /></Field>
              <Field label="Difficulty"><Segmented value={form.difficulty} onChange={(v) => set('difficulty', v)} options={['Easy', 'Medium', 'Hard']} /></Field>
              <Field label="Question types">
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <ChipToggle label="Multiple choice" on={true} onClick={() => {}} />
                  <ChipToggle label="True / False" on={form.includeTF} onClick={() => set('includeTF', !form.includeTF)} />
                </div>
              </Field>
            </>)}

            {type === 'wordsearch' && (<>
              <Field label="Grid size"><Segmented value={form.size} onChange={(v) => set('size', +v)} options={[{ value: 10, label: '10×10' }, { value: 12, label: '12×12' }, { value: 15, label: '15×15' }]} /></Field>
              <Field label="Difficulty" hint="Hard adds diagonal & backward words."><Segmented value={form.difficulty} onChange={(v) => set('difficulty', v)} options={['Easy', 'Medium', 'Hard']} /></Field>
              <Field label="Custom words (optional)" hint="One per line or comma-separated. Leave blank to auto-fill from the theme.">
                <TextArea value={form.customWords} onChange={(v) => set('customWords', v)} rows={3} placeholder="dolphin, octopus, coral…" />
              </Field>
            </>)}

            {type === 'vocab' && (<Field label="Number of words"><Stepper value={form.count} onChange={(v) => set('count', v)} min={4} max={12} /></Field>)}
            {type === 'reading' && (<Field label="Comprehension questions"><Stepper value={form.qCount} onChange={(v) => set('qCount', v)} min={2} max={8} /></Field>)}

            <Button size="lg" full icon="sparkles" onClick={doGenerate} disabled={!canGen} style={{ marginTop: 4 }}>
              {result ? 'Regenerate' : 'Generate'}
            </Button>
            {!canGen && <div style={{ fontSize: 12, color: t.textFaint, textAlign: 'center', marginTop: -8 }}>Enter a topic to begin</div>}
          </div>
        </Card>

        {/* PREVIEW */}
        <div style={{ flex: '1 1 460px', minWidth: 0 }}>
          {result && (
            <div className="hsk-no-print" style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, flexWrap: 'wrap',
              background: t.surface, border: `1px solid ${t.border}`, borderRadius: t.radius, padding: 10, boxShadow: t.shadowSm, position: 'sticky', top: 0, zIndex: 5 }}>
              <Badge soft={t.goodSoft} color={t.good} icon="sparkles">Draft ready</Badge>
              <div style={{ flex: 1 }} />
              <Segmented size="sm" value={editing ? 'edit' : 'view'} onChange={(v) => setEditing(v === 'edit')}
                options={[{ value: 'view', label: 'View', icon: 'book' }, { value: 'edit', label: 'Edit', icon: 'edit' }]} />
              <IconButton name="print" title="Print" onClick={() => window.print()} />
              <Button size="sm" variant="outline" icon="share" onClick={() => onShare(result)}>Share</Button>
              <Button size="sm" icon="save" onClick={() => { onSave(result); }}>Save to library</Button>
            </div>
          )}
          {loading ? <Card pad={0}><GenLoader label={`Generating your ${meta.label.toLowerCase()}…`} /></Card>
            : result ? <div className="hsk-rise"><MaterialDoc material={result} update={setResult} editing={editing} /></div>
              : <EmptyPreview t={t} type={type} />}
        </div>
      </div>
    </div>
  );
}

function EmptyPreview({ t, type }) {
  const meta = GEN_META[type];
  return (
    <div style={{ border: `2px dashed ${t.border}`, borderRadius: t.radius, padding: '60px 30px', textAlign: 'center',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, background: t.surface }}>
      <div style={{ width: 64, height: 64, borderRadius: 16, background: t.surfaceAlt, display: 'grid', placeItems: 'center', color: t.textFaint }}>
        <Icon name={meta.icon} size={32} />
      </div>
      <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, color: t.text }}>Your {meta.label.toLowerCase()} will appear here</div>
      <div style={{ color: t.textMuted, fontSize: 13.5, maxWidth: 340, lineHeight: 1.5 }}>
        Fill in a topic on the left and press <b style={{ color: t.text }}>Generate</b>. You can edit any part before printing or saving.
      </div>
    </div>
  );
}

/* Shared page header with back + breadcrumb */
function PageHead({ t, go, icon, type, title, sub, back }) {
  return (
    <div style={{ marginBottom: 22 }}>
      {back && <button onClick={back.onClick} className="hsk-no-print" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 'none',
        color: t.textMuted, cursor: 'pointer', fontFamily: t.fontBody, fontSize: 13, fontWeight: 600, padding: 0, marginBottom: 12 }}>
        <Icon name="arrowL" size={16} />{back.label}</button>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        {type && <GenBadge type={type} size={46} />}
        <div>
          <h1 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 25, letterSpacing: t.headingLetter, color: t.text }}>{title}</h1>
          {sub && <p style={{ margin: '4px 0 0', color: t.textMuted, fontSize: 14 }}>{sub}</p>}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GeneratorScreen, buildMaterial, titleCase, PageHead, EmptyPreview, SUBJECTS, GRADES, TOPIC_SUGGESTIONS });
