/* ===================================================================== *
 *  library.jsx — Library, Shared, full material view, Share modal
 * ===================================================================== */

function LibraryScreen({ library, go, onShare, onDelete, toast }) {
  const t = useT();
  const [q, setQ] = useState('');
  const [typeF, setTypeF] = useState('All');
  const [view, setView] = useState('grid');
  const typeOpts = ['All', 'worksheet', 'quiz', 'wordsearch', 'vocab', 'reading', 'unitstudy'];

  const items = library.filter((m) => {
    const okT = typeF === 'All' || m.type === typeF;
    const okQ = !q || (m.title + ' ' + m.subject).toLowerCase().includes(q.toLowerCase());
    return okT && okQ;
  });

  return (
    <div className="hsk-rise" style={{ maxWidth: 1080, margin: '0 auto' }}>
      <PageHead t={t} title="My Library" sub={`${library.length} saved materials — edit, print, or share any of them.`} />

      <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 18 }}>
        <div style={{ flex: '1 1 240px', maxWidth: 320 }}><TextInput value={q} onChange={setQ} placeholder="Search library…" icon="search" /></div>
        <div className="hsk-scroll" style={{ display: 'flex', gap: 7, overflowX: 'auto' }}>
          {typeOpts.map((ty) => (
            <ChipToggle key={ty} label={ty === 'All' ? 'All' : GEN_META[ty].label} icon={ty === 'All' ? 'grid' : GEN_META[ty].icon} on={typeF === ty} onClick={() => setTypeF(ty)} />
          ))}
        </div>
        <div style={{ flex: 1 }} />
        <Segmented size="sm" value={view} onChange={setView} options={[{ value: 'grid', icon: 'grid', label: '' }, { value: 'list', icon: 'list', label: '' }]} />
      </div>

      {items.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 60, color: t.textMuted }}>
          <div style={{ width: 60, height: 60, borderRadius: 16, background: t.surfaceAlt, display: 'grid', placeItems: 'center', margin: '0 auto 14px', color: t.textFaint }}><Icon name="library" size={30} /></div>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, color: t.text }}>Nothing here yet</div>
          <div style={{ fontSize: 13.5, marginTop: 6 }}>Generate something and tap <b style={{ color: t.text }}>Save to library</b>.</div>
          <div style={{ marginTop: 16, display: 'flex', justifyContent: 'center' }}><Button icon="spark" onClick={() => go({ name: 'gen', type: 'worksheet' })}>Create your first material</Button></div>
        </div>
      ) : view === 'grid' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
          {items.map((m) => <MaterialCard key={m.id} m={m} go={go} onShare={onShare} />)}
        </div>
      ) : (
        <Card pad={0} style={{ overflow: 'hidden' }}>
          {items.map((m, i) => <LibRow key={m.id} m={m} go={go} onShare={onShare} onDelete={onDelete} last={i === items.length - 1} />)}
        </Card>
      )}
    </div>
  );
}

function LibRow({ m, go, onShare, onDelete, last }) {
  const t = useT();
  const meta = GEN_META[m.type], col = subjectColor(m.subject);
  const [h, setH] = useState(false);
  return (
    <div onClick={() => go({ name: 'material', id: m.id })} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '13px 16px', cursor: 'pointer',
        borderBottom: last ? 'none' : `1px solid ${t.border}`, background: h ? t.surfaceAlt : 'transparent' }}>
      <GenBadge type={m.type} size={36} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14, color: t.text }}>{m.title}</div>
        <div style={{ fontSize: 12, color: t.textMuted, marginTop: 2 }}>{meta.label} · {m.grade} · {m.subject}</div>
      </div>
      <Badge soft={col.soft} color={col.c}>{m.subject}</Badge>
      <div style={{ display: 'flex', gap: 2, opacity: h ? 1 : 0.4 }}>
        <IconButton name="share" size="sm" onClick={(e) => { e.stopPropagation(); onShare(m); }} title="Share" />
        <IconButton name="trash" size="sm" onClick={(e) => { e.stopPropagation(); onDelete(m.id); }} title="Delete" />
      </div>
    </div>
  );
}

function SharedScreen({ shared, go }) {
  const t = useT();
  return (
    <div className="hsk-rise" style={{ maxWidth: 1080, margin: '0 auto' }}>
      <PageHead t={t} title="Shared with me" sub="Materials other homeschool parents have shared with you." />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        {CO_PARENTS.filter((p) => shared.some((s) => s.sharedBy === p.name)).map((p) => {
          const items = shared.filter((s) => s.sharedBy === p.name);
          return (
            <div key={p.name}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: p.color + '22', color: p.color, display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12 }}>{p.initials}</div>
                <span style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 15.5, color: t.text }}>{p.name}</span>
                <span style={{ color: t.textMuted, fontSize: 13 }}>shared {items.length} {items.length === 1 ? 'item' : 'items'}</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
                {items.map((m) => <MaterialCard key={m.id} m={m} go={go} />)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------- Full material view ------------------------- */
function MaterialView({ material, go, onUpdate, onShare, onDelete, fromShared }) {
  const t = useT();
  const [editing, setEditing] = useState(false);
  const meta = GEN_META[material.type];
  return (
    <div className="hsk-rise">
      <div className="hsk-no-print" style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        <button onClick={() => go({ name: fromShared ? 'shared' : 'library' })} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 'none',
          color: t.textMuted, cursor: 'pointer', fontFamily: t.fontBody, fontSize: 13, fontWeight: 600, padding: 0 }}>
          <Icon name="arrowL" size={16} />{fromShared ? 'Shared with me' : 'My Library'}
        </button>
        <div style={{ flex: 1 }} />
        {!fromShared && <Segmented size="sm" value={editing ? 'edit' : 'view'} onChange={(v) => setEditing(v === 'edit')} options={[{ value: 'view', label: 'View', icon: 'book' }, { value: 'edit', label: 'Edit', icon: 'edit' }]} />}
        <IconButton name="print" title="Print" onClick={() => window.print()} />
        <Button size="sm" variant="outline" icon="share" onClick={() => onShare(material)}>Share</Button>
        {fromShared
          ? <Button size="sm" icon="save" onClick={() => { onUpdate({ ...material, id: uid(), source: 'generated', sharedBy: undefined }, true); }}>Save a copy</Button>
          : <IconButton name="trash" title="Delete" onClick={() => { onDelete(material.id); go({ name: 'library' }); }} />}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, flexWrap: 'wrap' }} className="hsk-no-print">
        <Badge soft={subjectColor(material.subject).soft} color={subjectColor(material.subject).c} icon={meta.icon}>{meta.label}</Badge>
        <Badge soft={t.surfaceAlt}>{material.grade}</Badge>
        <Badge soft={t.surfaceAlt}>{material.subject}</Badge>
        {material.sharedBy && <Badge soft={t.surfaceAlt} icon="users">from {material.sharedBy}</Badge>}
      </div>
      <MaterialDoc material={material} update={fromShared ? () => {} : onUpdate} editing={editing} />
    </div>
  );
}

/* ----------------------------- Share modal ---------------------------- */
function ShareModal({ material, onClose, toast }) {
  const t = useT();
  const [picked, setPicked] = useState([]);
  const [copied, setCopied] = useState(false);
  const [msg, setMsg] = useState('');
  if (!material) return null;
  const link = `homeschoolkit.app/m/${material.id}`;
  const toggle = (n) => setPicked((p) => p.includes(n) ? p.filter((x) => x !== n) : [...p, n]);
  const doShare = () => {
    onClose();
    toast(picked.length ? `Shared with ${picked.length} ${picked.length === 1 ? 'parent' : 'parents'}` : 'Share link copied', 'share');
  };
  return (
    <Modal open onClose={onClose} title="Share material" width={480}>
      <div style={{ padding: '14px 20px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: t.surfaceAlt, borderRadius: t.radius, marginBottom: 18 }}>
          <GenBadge type={material.type} size={38} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontWeight: 600, fontSize: 14, color: t.text }}>{material.title}</div>
            <div style={{ fontSize: 12, color: t.textMuted }}>{GEN_META[material.type].label} · {material.grade}</div>
          </div>
        </div>

        <div style={{ fontSize: 12.5, fontWeight: 600, color: t.text, marginBottom: 8 }}>Share link</div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, border: `1px solid ${t.border}`, borderRadius: t.radiusSm, padding: '9px 11px', background: t.surfaceSunken, color: t.textMuted, fontSize: 13, fontFamily: t.fontMono, overflow: 'hidden' }}>
            <Icon name="link" size={15} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{link}</span>
          </div>
          <Button variant={copied ? 'soft' : 'outline'} icon={copied ? 'check' : 'copy'} onClick={() => { setCopied(true); navigator.clipboard && navigator.clipboard.writeText(link).catch(() => {}); }}>{copied ? 'Copied' : 'Copy'}</Button>
        </div>

        <div style={{ fontSize: 12.5, fontWeight: 600, color: t.text, marginBottom: 10 }}>Share with parents in your network</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 18 }}>
          {CO_PARENTS.map((p) => {
            const on = picked.includes(p.name);
            return (
              <div key={p.name} onClick={() => toggle(p.name)} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '9px 11px', borderRadius: t.radiusSm,
                border: `1px solid ${on ? t.accentLine : t.border}`, background: on ? t.accentSoft : t.surface, cursor: 'pointer', transition: 'all .12s' }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: p.color + '22', color: p.color, display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12 }}>{p.initials}</div>
                <span style={{ flex: 1, fontSize: 13.5, fontWeight: 600, color: t.text }}>{p.name}</span>
                <span style={{ width: 22, height: 22, borderRadius: 6, border: `1.5px solid ${on ? t.accent : t.borderStrong}`, background: on ? t.accent : 'transparent', display: 'grid', placeItems: 'center', color: '#fff' }}>{on && <Icon name="check" size={14} />}</span>
              </div>
            );
          })}
        </div>

        <TextArea value={msg} onChange={setMsg} rows={2} placeholder="Add a note (optional)…" style={{ width: '100%', marginBottom: 18 }} />
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button icon="share" onClick={doShare}>{picked.length ? `Share with ${picked.length}` : 'Copy link & share'}</Button>
        </div>
      </div>
    </Modal>
  );
}

Object.assign(window, { LibraryScreen, LibRow, SharedScreen, MaterialView, ShareModal });
