/* ===================================================================== *
 *  docs.jsx — Printable material documents + inline editing
 *  MaterialDoc renders any generated material as a clean "paper" sheet.
 * ===================================================================== */

const EditCtx = createContext({ editing: false });

function Editable({ value, onChange, tag = 'span', style, block }) {
  const t = useT();
  const { editing } = useContext(EditCtx);
  const ref = useRef(null);
  if (!editing) return React.createElement(tag, { style }, value);
  return React.createElement(tag, {
    ref, contentEditable: true, suppressContentEditableWarning: true,
    onBlur: (e) => onChange(e.target.innerText),
    style: { ...style, outline: 'none', background: t.accentSoft, borderRadius: 4, padding: '0 3px',
      boxShadow: `inset 0 0 0 1px ${t.accentLine}`, cursor: 'text', display: block ? 'block' : 'inline-block', minWidth: 30 },
  }, value);
}

/* Paper sheet wrapper */
function Sheet({ children, t }) {
  return (
    <div className="hsk-doc" id="hsk-print-target" style={{ background: '#fff', borderRadius: t.radius, border: `1px solid ${t.border}`,
      boxShadow: t.shadow, padding: '44px 48px', maxWidth: 780, margin: '0 auto', color: '#1b2430' }}>
      {children}
    </div>
  );
}

function SheetHeader({ t, title, subtitle, onTitle, badge }) {
  return (
    <div style={{ borderBottom: `2px solid #1b2430`, paddingBottom: 14, marginBottom: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, fontSize: 12.5, color: '#6a7585', marginBottom: 14 }}>
        <span>Name: ______________________</span>
        <span>Date: __________</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12 }}>
        <h1 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 26, letterSpacing: t.headingLetter, lineHeight: 1.1 }}>
          <Editable value={title} onChange={onTitle} tag="span" />
        </h1>
        {badge}
      </div>
      {subtitle && <p style={{ margin: '8px 0 0', color: '#6a7585', fontSize: 13.5 }}>{subtitle}</p>}
    </div>
  );
}

const blankLine = (w = 120) => (<span style={{ display: 'inline-block', borderBottom: '1.5px solid #c4ccd6', width: w, height: 14, verticalAlign: 'middle' }} />);

/* ------------------------------ Worksheet ----------------------------- */
function WorksheetDoc({ material, update }) {
  const t = useT();
  const { editing } = useContext(EditCtx);
  const c = material.content;
  const isMath = material.subject === 'Math';
  const setTitle = (v) => update({ ...material, title: v });
  const setProblem = (i, v) => { const p = [...c.problems]; p[i] = { ...p[i], q: v }; update({ ...material, content: { ...c, problems: p } }); };
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle={c.instructions} badge={<Badge soft="#e8eff8" color="#3863a8">{material.grade} · {material.subject}</Badge>} />
      <ol style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'grid',
        gridTemplateColumns: isMath ? 'repeat(2, 1fr)' : '1fr', gap: isMath ? '20px 32px' : 18, counterReset: 'pr' }}>
        {c.problems.map((p, i) => (
          <li key={i} style={{ display: 'flex', gap: 12, fontSize: isMath ? 17 : 14.5, lineHeight: 1.5 }}>
            <span style={{ fontWeight: 700, color: '#3863a8', fontFamily: t.fontMono, flex: '0 0 auto' }}>{i + 1}.</span>
            <div style={{ flex: 1 }}>
              <span style={{ fontFamily: isMath ? t.fontMono : t.fontBody, fontWeight: isMath ? 600 : 500 }}>
                <Editable value={p.q} onChange={(v) => setProblem(i, v)} />
              </span>
              {isMath ? <span style={{ marginLeft: 8 }}>{blankLine(70)}</span>
                : <div style={{ marginTop: 8, borderBottom: '1px solid #dce2ea', height: 18 }} />}
              {!isMath && p.kind === 'short' && <div style={{ marginTop: 6, borderBottom: '1px solid #dce2ea', height: 18 }} />}
            </div>
          </li>
        ))}
      </ol>
      {c.hasKey && (
        <div className="hsk-key" style={{ marginTop: 30, paddingTop: 18, borderTop: `1px dashed #c4ccd6` }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 14, color: '#6a7585', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="check" size={15} stroke="#2f8a63" /> Answer Key
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '6px 16px', fontSize: 12.5, color: '#6a7585' }}>
            {c.problems.map((p, i) => (
              <div key={i}><b style={{ color: '#3863a8', fontFamily: t.fontMono }}>{i + 1}.</b> {p.answer}</div>
            ))}
          </div>
        </div>
      )}
    </Sheet>
  );
}

/* -------------------------------- Quiz -------------------------------- */
function QuizDoc({ material, update }) {
  const t = useT();
  const c = material.content;
  const setTitle = (v) => update({ ...material, title: v });
  const setQ = (i, v) => { const q = [...c.questions]; q[i] = { ...q[i], q: v }; update({ ...material, content: { ...c, questions: q } }); };
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle={`${c.questions.length} questions · circle the best answer`} badge={<Badge soft="#e2f1ea" color="#2f8a63">{material.grade} · {material.subject}</Badge>} />
      <ol style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 20 }}>
        {c.questions.map((q, i) => (
          <li key={i} style={{ display: 'flex', gap: 12 }}>
            <span style={{ fontWeight: 700, color: '#2f8a63', fontFamily: t.fontMono }}>{i + 1}.</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 500, lineHeight: 1.4 }}><Editable value={q.q} onChange={(v) => setQ(i, v)} /></div>
              {q.type === 'mcq' && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '8px 18px', marginTop: 10 }}>
                  {q.choices.map((ch, ci) => (
                    <div key={ci} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 14 }}>
                      <span style={{ width: 22, height: 22, borderRadius: '50%', border: '1.5px solid #b4bdc9', display: 'grid', placeItems: 'center',
                        fontSize: 12, fontWeight: 700, color: '#6a7585', flex: '0 0 22px' }}>{'ABCD'[ci]}</span>
                      {ch}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </li>
        ))}
      </ol>
      <div className="hsk-key" style={{ marginTop: 30, paddingTop: 18, borderTop: `1px dashed #c4ccd6` }}>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 14, color: '#6a7585', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon name="check" size={15} stroke="#2f8a63" /> Answer Key
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px, 1fr))', gap: '6px 16px', fontSize: 13, color: '#6a7585' }}>
          {c.questions.map((q, i) => (
            <div key={i}><b style={{ color: '#2f8a63', fontFamily: t.fontMono }}>{i + 1}.</b> {'ABCD'[q.answer]} — {q.choices[q.answer]}</div>
          ))}
        </div>
      </div>
    </Sheet>
  );
}

/* ----------------------------- Word Search ---------------------------- */
function WordSearchDoc({ material, update }) {
  const t = useT();
  const [showKey, setShowKey] = useState(false);
  const c = material.content;
  const setTitle = (v) => update({ ...material, title: v });
  const solSet = new Set();
  (c.placed || []).forEach((p) => p.cells.forEach(([r, cc]) => solSet.add(r + ',' + cc)));
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle="Find and circle each word from the word bank." badge={<Badge soft="#f5e6f0" color="#a8538f">{material.grade || 'All ages'} · Puzzle</Badge>} />
      <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${c.size}, 1fr)`, gap: 2, flex: '0 0 auto' }}>
          {c.grid.map((row, r) => row.map((ch, cc) => {
            const hit = showKey && solSet.has(r + ',' + cc);
            return (
              <div key={r + '-' + cc} style={{ width: 26, height: 26, display: 'grid', placeItems: 'center',
                fontFamily: t.fontMono, fontSize: 14, fontWeight: 600, color: hit ? '#fff' : '#1b2430',
                background: hit ? '#a8538f' : 'transparent', borderRadius: hit ? '50%' : 0 }}>{ch}</div>
            );
          }))}
        </div>
        <div style={{ flex: 1, minWidth: 160 }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 14, marginBottom: 10 }}>Word Bank</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '7px 14px' }}>
            {c.words.map((w) => (
              <div key={w} style={{ fontFamily: t.fontMono, fontSize: 12.5, letterSpacing: '0.05em', color: '#3a4452', display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 5, height: 5, borderRadius: '50%', background: '#a8538f' }} />{w}
              </div>
            ))}
          </div>
          <button onClick={() => setShowKey((s) => !s)} className="hsk-no-print" style={{ marginTop: 18, display: 'inline-flex', alignItems: 'center', gap: 6,
            background: 'transparent', border: `1px solid ${t.border}`, borderRadius: t.radiusSm, padding: '7px 12px', cursor: 'pointer',
            fontFamily: t.fontBody, fontSize: 12.5, fontWeight: 600, color: t.textMuted }}>
            <Icon name={showKey ? 'close' : 'check'} size={14} />{showKey ? 'Hide' : 'Show'} solution
          </button>
        </div>
      </div>
    </Sheet>
  );
}

/* ----------------------------- Vocabulary ----------------------------- */
function VocabDoc({ material, update }) {
  const t = useT();
  const [mode, setMode] = useState('list');
  const [flipped, setFlipped] = useState({});
  const c = material.content;
  const setTitle = (v) => update({ ...material, title: v });
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle={`${c.words.length} vocabulary words`} badge={
          <div className="hsk-no-print"><Segmented size="sm" value={mode} onChange={setMode} options={[{ value: 'list', label: 'List', icon: 'list' }, { value: 'cards', label: 'Flashcards', icon: 'grid' }]} /></div>
        } />
      {mode === 'list' ? (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {c.words.map((w, i) => (
            <div key={i} style={{ display: 'flex', gap: 14, padding: '13px 0', borderBottom: i < c.words.length - 1 ? '1px solid #e8edf2' : 'none' }}>
              <span style={{ fontFamily: t.fontMono, fontSize: 12, color: '#a8538f', fontWeight: 700, flex: '0 0 22px' }}>{i + 1}</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                  <span style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 16, color: '#1b2430' }}>{w.word}</span>
                  <span style={{ fontStyle: 'italic', fontSize: 12.5, color: '#9aa4b2' }}>{w.pos}</span>
                </div>
                <div style={{ fontSize: 14, color: '#3a4452', marginTop: 3 }}>{w.def}</div>
                <div style={{ fontSize: 13, color: '#6a7585', marginTop: 4, fontStyle: 'italic' }}>“{w.sentence}”</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 12 }}>
          {c.words.map((w, i) => {
            const fl = flipped[i];
            return (
              <div key={i} onClick={() => setFlipped((f) => ({ ...f, [i]: !f[i] }))}
                style={{ height: 120, borderRadius: t.radius, border: `1px solid ${fl ? t.accentLine : t.border}`,
                  background: fl ? '#f5e6f0' : t.surface, padding: 14, cursor: 'pointer', display: 'flex',
                  flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', transition: 'all .2s' }}>
                {fl ? <div style={{ fontSize: 12.5, color: '#3a4452', lineHeight: 1.4 }}>{w.def}</div>
                  : <><div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 17, color: '#1b2430' }}>{w.word}</div>
                    <div style={{ fontSize: 11, color: '#9aa4b2', marginTop: 6 }}>tap to flip</div></>}
              </div>
            );
          })}
        </div>
      )}
    </Sheet>
  );
}

/* --------------------------- Reading Passage -------------------------- */
function ReadingDoc({ material, update }) {
  const t = useT();
  const c = material.content;
  const setTitle = (v) => update({ ...material, title: v });
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle={`Reading passage · Lexile ${c.lexile}`} badge={<Badge soft="#dff0f0" color="#2b8a8a">{material.grade} · Reading</Badge>} />
      <div style={{ fontSize: 15.5, lineHeight: 1.75, color: '#2a3340', columnGap: 0 }}>
        {c.passage.map((para, i) => <p key={i} style={{ margin: i === 0 ? '0 0 14px' : '0 0 14px', textIndent: i === 0 ? 0 : 0 }}>{para}</p>)}
      </div>
      <div style={{ marginTop: 26, paddingTop: 20, borderTop: `2px solid #1b2430` }}>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 16, marginBottom: 14 }}>Comprehension Questions</div>
        <ol style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {c.questions.map((q, i) => (
            <li key={i} style={{ display: 'flex', gap: 12 }}>
              <span style={{ fontWeight: 700, color: '#2b8a8a', fontFamily: t.fontMono }}>{i + 1}.</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14.5, fontWeight: 500 }}>{q.q}</div>
                <div style={{ marginTop: 8, borderBottom: '1px solid #dce2ea', height: 18 }} />
                <div style={{ marginTop: 6, borderBottom: '1px solid #dce2ea', height: 18 }} />
              </div>
            </li>
          ))}
        </ol>
        <div className="hsk-key" style={{ marginTop: 22, paddingTop: 14, borderTop: '1px dashed #c4ccd6' }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 13.5, color: '#6a7585', marginBottom: 8 }}>Suggested Answers</div>
          {c.questions.map((q, i) => <div key={i} style={{ fontSize: 12.5, color: '#6a7585', marginBottom: 4 }}><b style={{ color: '#2b8a8a', fontFamily: t.fontMono }}>{i + 1}.</b> {q.answer}</div>)}
        </div>
      </div>
    </Sheet>
  );
}

/* ----------------------------- Unit Study ----------------------------- */
function UnitStudyDoc({ material, update }) {
  const t = useT();
  const c = material.content;
  const setTitle = (v) => update({ ...material, title: v });
  const Section = ({ icon, title, color, children }) => (
    <div style={{ marginBottom: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <div style={{ width: 26, height: 26, borderRadius: 7, background: (color || '#3863a8') + '22', color: color || '#3863a8', display: 'grid', placeItems: 'center' }}><Icon name={icon} size={15} stroke={color || '#3863a8'} /></div>
        <h3 style={{ margin: 0, fontFamily: t.fontDisplay, fontWeight: 600, fontSize: 16, color: '#1b2430' }}>{title}</h3>
      </div>
      {children}
    </div>
  );
  const bullets = (items, color) => (
    <ul style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
      {items.map((x, i) => (
        <li key={i} style={{ display: 'flex', gap: 10, fontSize: 14, lineHeight: 1.45, color: '#2a3340' }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: color || '#3863a8', marginTop: 7, flex: '0 0 6px' }} />{x}
        </li>
      ))}
    </ul>
  );
  return (
    <Sheet t={t}>
      <SheetHeader t={t} title={material.title} onTitle={setTitle}
        subtitle={c.overview} badge={<Badge soft="#f5e6f0" color="#a8538f" icon="place">Unit Study</Badge>} />
      <Section icon="bolt" title="Big Ideas" color="#3863a8">{bullets(c.bigIdeas, '#3863a8')}</Section>
      <Section icon="vocab" title="Key Vocabulary" color="#a8538f">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '10px 18px' }}>
          {c.vocab.map((v, i) => <div key={i} style={{ fontSize: 13.5 }}><b style={{ color: '#1b2430' }}>{v.word}</b> <span style={{ color: '#6a7585' }}>— {v.def}</span></div>)}
        </div>
      </Section>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 18 }}>
        <Section icon="book" title="Before the Visit" color="#2f8a63">{bullets(c.beforeVisit, '#2f8a63')}</Section>
        <Section icon="search" title="During the Visit" color="#c0762e">{bullets(c.duringVisit, '#c0762e')}</Section>
        <Section icon="check" title="After the Visit" color="#3863a8">{bullets(c.afterVisit, '#3863a8')}</Section>
      </div>
      <Section icon="spark" title="Hands-on Activities" color="#a8538f">{bullets(c.activities, '#a8538f')}</Section>
      <Section icon="quiz" title="Discussion Questions" color="#2b8a8a">{bullets(c.discussion, '#2b8a8a')}</Section>
      <Section icon="flag" title="Scavenger Hunt" color="#c0762e">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10 }}>
          {c.scavenger.map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5, color: '#2a3340' }}>
              <span style={{ width: 18, height: 18, border: '1.5px solid #b4bdc9', borderRadius: 4, flex: '0 0 18px' }} />{s}
            </div>
          ))}
        </div>
      </Section>
    </Sheet>
  );
}

function MaterialDoc({ material, update = () => {}, editing = false }) {
  const map = { worksheet: WorksheetDoc, quiz: QuizDoc, wordsearch: WordSearchDoc, vocab: VocabDoc, reading: ReadingDoc, unitstudy: UnitStudyDoc };
  const Comp = map[material.type] || WorksheetDoc;
  return <EditCtx.Provider value={{ editing }}><Comp material={material} update={update} /></EditCtx.Provider>;
}

/* print styles */
(function injectPrint() {
  if (document.getElementById('hsk-print-css')) return;
  const s = document.createElement('style');
  s.id = 'hsk-print-css';
  s.textContent = `
    @media print {
      body * { visibility: hidden !important; }
      #hsk-print-target, #hsk-print-target * { visibility: visible !important; }
      #hsk-print-target { position: absolute !important; left: 0; top: 0; width: 100% !important; max-width: none !important;
        box-shadow: none !important; border: none !important; padding: 0 !important; margin: 0 !important; }
      .hsk-no-print { display: none !important; }
      @page { margin: 18mm; }
    }
  `;
  document.head.appendChild(s);
})();

Object.assign(window, { MaterialDoc, WorksheetDoc, QuizDoc, WordSearchDoc, VocabDoc, ReadingDoc, UnitStudyDoc, EditCtx, Editable, Sheet });
